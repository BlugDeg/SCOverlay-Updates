using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using SCOverlay.API;

namespace SCOverlay.Addons.Demo
{
    [Addon]
    public class DemoAddon : IAddon
    {
        private IAddonHost? _host;
        private Form? _testWindow;
        private bool _triggerDrawException = false;

        public string Name => "API Test Suite";
        public string Author => "Test Department";
        public string Version => "1.0";

        public void Initialize(IAddonHost host)
        {
            _host = host;
            _host.LogInfo("[DemoAddon] >> Initialize << I am alive!");
            _host.RegisterHotkey(OnTestHotkey, "Demo_TestHotkey", "Ctrl+F1");
        }

        public IEnumerable<AddonButton> GetMainMenuButtons()
        {
            yield break;
        }

        public IEnumerable<AddonControl> GetSettingsControls()
        {
            string groupName = "Debug Tools";

            yield return new AddonControl("demo_log_test", "Run Logging & Translation Test", "RebindButton", () => "Click to Run",
                () => {
                    _host?.LogInfo("[DemoAddon] >> TEST << This is an info message.");
                    _host?.LogError("[DemoAddon] >> TEST << This is an error message.", new Exception("This is a test exception."));
                    string translatedText = _host?.T("tray.exit") ?? "Translation failed";
                    _host?.Window.ShowNotification($"Translation for 'tray.exit' is: '{translatedText}'");
                },
                group: groupName
            );

            yield return new AddonControl("demo_sound_test", "Run Sound & Notification Test", "RebindButton", () => "Click to Run",
                () => {
                    _host?.Sound.PlayFile(@"Resources\hostile.wav");
                    _host?.Window.ShowNotification("API Test Successful!");
                },
                group: groupName
            );

            yield return new AddonControl("demo_window_test", "Create Themed Window", "RebindButton", () => "Click to Open",
                () => {
                    if (_host == null) return;
                    _testWindow?.Close(); _testWindow?.Dispose();
                    _testWindow = _host.Window.CreateThemedWindow("My Addon Window");
                    var label = new Label { Text = "Window created via API!", Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleCenter, ForeColor = _host.Theme_Text };
                    _testWindow.Controls.Add(label);
                    _testWindow.Show();
                },
                group: groupName
            );

            yield return new AddonControl("demo_hotkey_test", "Rebind Test Hotkey", "RebindButton", () => _host?.GetSetting("Demo_TestHotkey", "Ctrl+F1") ?? "N/A",
                () => {
                    if (_host == null) return;
                    string currentHotkey = _host.GetSetting("Demo_TestHotkey", "Ctrl+F1");
                    if (_host.ShowHotkeyDialog(currentHotkey, out string newHotkey))
                    {
                        _host.UnregisterHotkey("Demo_TestHotkey");
                        _host.SetSetting("Demo_TestHotkey", newHotkey);
                        _host.RegisterHotkey(OnTestHotkey, "Demo_TestHotkey", "Ctrl+F1");
                        _host.Window.ShowNotification($"Hotkey set to: {newHotkey}");
                        _host.InvalidateOverlay();
                    }
                },
                group: groupName
            );
            
            yield return new AddonControl("demo_stress_good", "Run GOOD Stress Test (10s)", "RebindButton", () => "Click to Run",
                () => {
                    _host?.RequestHighPerformanceMode(this, "User-initiated stress test");
                    _host?.Window.ShowNotification("Starting GOOD Stress Test for 10s...");
                    StartStressTest(true);
                },
                group: groupName
            );
            
            yield return new AddonControl("demo_stress_bad", "Run BAD Stress Test (10s)", "RebindButton", () => "Click to be Ejected",
                () => {
                    _host?.Window.ShowNotification("Starting BAD Stress Test for 10s...");
                    StartStressTest(false);
                },
                group: groupName
            );

            yield return new AddonControl("demo_crash_test", "Trigger Draw Exception", "RebindButton", () => "Click to Test",
                () => {
                    _triggerDrawException = true;
                    _host?.InvalidateOverlay();
                },
                group: groupName
            );
        }

        private void OnTestHotkey()
        {
            _host?.Window.ShowNotification("DemoAddon Hotkey was pressed!");
        }
        
        private void StartStressTest(bool releaseExemptionWhenDone)
        {
            int durationSeconds = 10;
            int threadCount = Environment.ProcessorCount;
            var cts = new System.Threading.CancellationTokenSource(durationSeconds * 1000);
            for (int i = 0; i < threadCount; i++) { System.Threading.Tasks.Task.Run(() => { while (!cts.Token.IsCancellationRequested) { } }); }
            if (releaseExemptionWhenDone) { System.Threading.Tasks.Task.Delay(durationSeconds * 1000).ContinueWith(_ => { _host?.ReleaseHighPerformanceMode(this); }); }
        }

        public void Draw(Graphics g, Rectangle bounds)
        {
            if (_triggerDrawException)
            {
                _triggerDrawException = false;
                throw new InvalidOperationException("Deliberate crash test from DemoAddon's Draw method.");
            }
        }
        
        public IDictionary<string, (string en, string de)> GetLocalizations()
        {
            // Leere Implementierung, um die Schnittstelle zu erfüllen.
            return new Dictionary<string, (string en, string de)>();
        }

        public void OnOverlayVisibilityChanged(bool isVisible) { }
        public void Shutdown() { _testWindow?.Dispose(); }
    }
}