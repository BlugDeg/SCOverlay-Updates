﻿using SCOverlay.API;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;

namespace SCOverlay.Addons.NewAddon
{
    // Das [Addon]-Attribut markiert diese Klasse als Einstiegspunkt für SCOverlay.
    [Addon]
    public class NewAddon : IAddon
    {
        // Eine private Variable, um die Host-Schnittstelle zu speichern.
        private IAddonHost? _host;

        // Implementierung der IAddon-Schnittstelle
        public string Name => "NewAddon";
        public string Author => "Your Name";

        // Liest die Version dynamisch aus den Assembly-Informationen (die in der .csproj festgelegt sind).
        public string Version => GetType().Assembly.GetName().Version?.ToString() ?? "0.0.0.0";

        // Diese Methode wird vom SCOverlay-Host aufgerufen, wenn das Addon geladen wird.
        public void Initialize(IAddonHost host)
        {
            _host = host;
            _host.LogInfo($"[NewAddon] Initializing Addon v{Version}...");
        }

        // Diese Methode wird aufgerufen, um die Buttons für das Hauptmenü zu erstellen.
        public IEnumerable<AddonButton> GetMainMenuButtons()
        {
            // 'yield return' ist eine einfache Möglichkeit, eine Liste von Elementen zurückzugeben.
            // Wir erstellen hier nur einen einzigen Button.
            yield return new AddonButton(
                id: "NewAddon_MainButton",
                getLabel: () => "NewAddon", // Der Text, der auf dem Button angezeigt wird.
                onClick: () => {
                    // Die Aktion, die ausgeführt wird, wenn der Button geklickt wird.
                    _host?.LogInfo("[NewAddon] 'NewAddon' button was clicked!");
                    _host?.Window.ShowNotification("NewAddon button works!");
                }
            );
        }

        #region Leere Implementierungen für die restlichen Interface-Methoden

        public void Shutdown() { }
        public void Draw(Graphics g, Rectangle bounds) { }
        public void OnOverlayVisibilityChanged(bool isVisible) { }
        public IEnumerable<AddonControl> GetSettingsControls() => Enumerable.Empty<AddonControl>();
        public IDictionary<string, (string en, string de)> GetLocalizations() => new Dictionary<string, (string, string)>();

        #endregion
    }
}