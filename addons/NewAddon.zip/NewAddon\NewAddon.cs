using SCOverlay.API;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;

namespace SCOverlay.Addons.NewAddon
{
    // The [Addon] attribute marks this class as the entry point for SCOverlay.
    // Das [Addon]-Attribut markiert diese Klasse als Einstiegspunkt für SCOverlay.
    [Addon]
    public class NewAddon : IAddon
    {
        // Keep the host: it is your toolbox for everything the core offers.
        // Den Host merken: er ist die Werkzeugkiste für alles, was der Core bietet.
        private IAddonHost? _host;

        public string Name => "NewAddon";
        public string Author => "Your Name";

        // Read the version from the assembly (set in the .csproj).
        // Liest die Version aus der Assembly (in der .csproj festgelegt).
        public string Version => GetType().Assembly.GetName().Version?.ToString() ?? "0.0.0.0";

        // One short line shown under the name on the menu tile (max. 40 characters).
        // Ein Halbsatz unter dem Namen auf der Kachel (höchstens 40 Zeichen).
        public string Kurzbeschreibung => "Says hello from the overlay";

        // Called once when the addon is loaded. Only store the host here;
        // host.T() returns raw keys until Initialize has finished.
        // Wird einmal beim Laden aufgerufen. Hier nur den Host merken;
        // host.T() liefert bis nach Initialize nur die rohen Schlüssel.
        public void Initialize(IAddonHost host)
        {
            _host = host;
            _host.LogInfo($"[NewAddon] Initializing v{Version}...");
        }

        // The tiles this addon shows in the main menu.
        // Die Kacheln, die dieses Addon im Hauptmenü zeigt.
        public IEnumerable<AddonButton> GetMainMenuButtons()
        {
            yield return new AddonButton(
                id: "NewAddon_MainButton",
                getLabel: () => "NewAddon",
                onClick: () =>
                {
                    _host?.LogInfo("[NewAddon] Button clicked.");
                    // Toast = pop-up bottom right. ShowNotification = big HUD text on screen.
                    // Toast = Meldung unten rechts. ShowNotification = grosser HUD-Text.
                    _host?.Window.ShowToast("NewAddon works!", "NewAddon", NotificationLevel.Success, 4);
                },
                iconKey: "sheet" // Built-in glyph key; or pass an Image for your own symbol.
            );
        }

        #region Empty implementations for the remaining interface members

        public void Shutdown() { }
        public void Draw(Graphics g, Rectangle bounds) { }
        public void OnOverlayVisibilityChanged(bool isVisible) { }
        public IEnumerable<AddonControl> GetSettingsControls() => Enumerable.Empty<AddonControl>();
        public IDictionary<string, (string en, string de)> GetLocalizations() => new Dictionary<string, (string, string)>();

        #endregion
    }
}
