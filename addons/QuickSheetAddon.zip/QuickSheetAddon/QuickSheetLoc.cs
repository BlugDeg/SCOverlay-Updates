using System.Collections.Generic;

namespace SCOverlay.Addons.QuickSheet
{
    public static class QuickSheetLoc
    {
        public static readonly Dictionary<string, (string en, string de)> Map = new()
        {
            // --- UI Elements ---
            ["quicksheet.menu.readme"] = ("Readme", "Liesmich"),
            ["quicksheet.readme.title"] = ("QuickSheet Readme", "QuickSheet Liesmich"),
            
            // --- Tooltips ---
            ["tooltip.pin"] = ("PIN: The window stays on top of all other applications.", "PIN: Das Fenster bleibt über allen anderen Anwendungen im Vordergrund."),
            ["tooltip.win"] = ("WIN: The window behaves like a normal window.", "WIN: Das Fenster verhält sich wie ein normales Fenster."),

            // --- Readme Content (NEUE, VERBESSERTE VERSION) ---
            ["quicksheet.readme.content"] = (
                @"--- QuickSheet Guide ---

1. How the PIN/WIN System Works (Most Important Feature):
   - Every sheet window has a button in the top-left corner.

   - [PIN] (Pinned): The window remains **always visible** and on top of all other applications, **even when the SCOverlay panel is hidden.** This is the default mode and is ideal for important references you need to see at all times during gameplay.

   - [WIN] (Window Mode): In this mode, the sheet acts as part of the overlay. It **hides together with the main panel** when you close the overlay (e.g., with your hotkey) and **reappears when you open the panel.** This is perfect for sheets you only need while actively working in the overlay menu.

2. How to Add Your Images (Sheets):
   - In your addon's folder ('SCOverlay/addons/QuickSheet'), create a new folder named 'sheets'.
   - Place your .png or .jpg image files directly into this 'sheets' folder.

3. How to Create Categories (Sub-Menus):
   - You can create sub-folders inside the 'sheets' folder to organize your images.
   - For example: 'sheets/Trading/' or 'sheets/Mining/Bountiful Harvest/'.
   - The addon will automatically create a menu structure based on your folder hierarchy.

4. Special Feature: Folder Shortcuts
   - If you have a folder that contains ONLY ONE image, and the image has the exact same name as the folder (e.g., folder 'Refinery' contains 'Refinery.png'), clicking that folder in the menu will directly open the image instead of navigating into the folder. This is useful for creating clean, direct links.

Enjoy using QuickSheets!",
                
                @"--- QuickSheet Anleitung ---

1. Wie das PIN/WIN-System funktioniert (Wichtigstes Feature):
   - Jedes Sheet-Fenster hat oben links einen Button.

   - **[PIN] (Angepinnt):** Das Fenster bleibt **immer sichtbar** und über allen anderen Anwendungen im Vordergrund, **auch wenn das SCOverlay-Panel ausgeblendet wird.** Dies ist der Standard-Modus und ideal für wichtige Referenzen, die du während des Spielens jederzeit sehen musst.

   - **[WIN] (Fenster-Modus):** In diesem Modus verhält sich das Sheet wie ein Teil des Overlays. Es wird **zusammen mit dem Haupt-Panel ausgeblendet**, wenn du das Overlay schließt (z.B. mit deinem Hotkey), und **erscheint wieder, wenn du das Panel öffnest.** Ideal für Sheets, die du nur brauchst, während du aktiv im Overlay-Menü arbeitest.

2. Wie du deine Bilder (Sheets) hinzufügst:
   - Erstelle in deinem Addon-Verzeichnis ('SCOverlay/addons/QuickSheet') einen neuen Ordner mit dem Namen 'sheets'.
   - Platziere deine .png- oder .jpg-Bilddateien direkt in diesen 'sheets'-Ordner.

3. Wie du Kategorien (Untermenüs) erstellst:
   - Du kannst Unterordner im 'sheets'-Ordner erstellen, um deine Bilder zu organisieren.
   - Zum Beispiel: 'sheets/Handel/' oder 'sheets/Mining/Bountiful Harvest/'.
   - Das Addon erstellt automatisch eine Menüstruktur, die auf deiner Ordnerhierarchie basiert.

4. Spezialfunktion: Ordner-Verknüpfungen
   - Wenn ein Ordner NUR EIN EINZIGES Bild enthält und das Bild exakt denselben Namen hat wie der Ordner (z.B. Ordner 'Raffinerie' enthält 'Raffinerie.png'), wird beim Klicken auf diesen Ordner im Menü direkt das Bild geöffnet, anstatt in den Ordner zu navigieren. Das ist nützlich, um saubere, direkte Links zu erstellen.

Viel Spass mit den QuickSheets!"
            )
        };
    }
}