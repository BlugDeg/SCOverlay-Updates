using System;
using System.Drawing;
using System.Windows.Forms;
using SCOverlay.API;

namespace SCOverlay.Addons.QuickSheet
{
    public class ReadmeForm : Form
    {
        public ReadmeForm(IAddonHost host)
        {
            this.Text = host.T("quicksheet.readme.title");
            this.FormBorderStyle = FormBorderStyle.SizableToolWindow;
            this.ShowInTaskbar = false;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Size = new Size(600, 500);
            this.TopMost = true;

            Color opaqueBackgroundColor = Color.FromArgb(255, host.Theme_Background);
            
            this.BackColor = opaqueBackgroundColor;
            this.ForeColor = host.Theme_Text;

            var richTextBox = new RichTextBox
            {
                Dock = DockStyle.Fill,
                ReadOnly = true,
                BackColor = this.BackColor,
                ForeColor = this.ForeColor,
                BorderStyle = BorderStyle.None,
                Font = new Font("Consolas", 10F, FontStyle.Regular, GraphicsUnit.Point),
                Text = host.T("quicksheet.readme.content"),
                Padding = new Padding(10)
            };

            this.Controls.Add(richTextBox);

            // =================================================================
            // ===== NEU: Event-Handler für das "Shown"-Ereignis hinzufügen =====
            // =================================================================
            this.Shown += ReadmeForm_Shown;
        }

        /// <summary>
        /// Diese Methode wird aufgerufen, sobald das Fenster zum ersten Mal angezeigt wird.
        /// Wir nutzen sie, um das Fenster aggressiv in den Vordergrund zu zwingen.
        /// </summary>
        private void ReadmeForm_Shown(object? sender, EventArgs e)
        {
            // Gibt dem Fenster den Eingabefokus
            this.Activate(); 
            
            // Bringt das Fenster in der Z-Reihenfolge ganz nach oben
            this.BringToFront(); 
        }
    }
}