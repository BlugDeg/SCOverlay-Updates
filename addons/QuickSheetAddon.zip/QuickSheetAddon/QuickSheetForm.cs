using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using SCOverlay.API;
using SixLabors.ImageSharp;

namespace SCOverlay.Addons.QuickSheet
{
    public class QuickSheetForm : Form
    {
        private readonly PictureBox _pictureBox;
        private readonly Button _pinButton;
        private bool _isPinned;
        private readonly ToolTip _toolTip;
        private readonly IAddonHost _host;
        private readonly Action<bool> _onPinStateChanged;

        public bool IsPinned => _isPinned;

        public QuickSheetForm(string imagePath, IAddonHost host, bool initialIsPinned, Action<bool> onPinStateChanged)
        {
            _host = host;
            _host.LogInfo($"[QuickSheet] Initializing QuickSheetForm for image: {imagePath}");
            
            _isPinned = initialIsPinned;
            _onPinStateChanged = onPinStateChanged;

            this.Text = "QuickSheet Viewer";
            this.FormBorderStyle = FormBorderStyle.SizableToolWindow;
            this.ShowInTaskbar = false;
            this.StartPosition = FormStartPosition.Manual;
            this.TopMost = _isPinned;
            this.BackColor = System.Drawing.Color.FromArgb(10, 10, 10);
            this.MinimumSize = new System.Drawing.Size(200, 200);

            _pictureBox = new PictureBox { Dock = DockStyle.Fill, SizeMode = PictureBoxSizeMode.Zoom };
            this.Controls.Add(_pictureBox);

            try
            {
                if (File.Exists(imagePath))
                {
                    using (SixLabors.ImageSharp.Image image = SixLabors.ImageSharp.Image.Load(imagePath))
                    {
                        var screen = Screen.PrimaryScreen ?? Screen.AllScreens[0];
                        var screenArea = screen.WorkingArea;
                        int maxWidth = (int)(screenArea.Width * 0.4);
                        int maxHeight = (int)(screenArea.Height * 0.8);
                        float imgAspect = (float)image.Width / image.Height;
                        int newWidth = maxWidth;
                        int newHeight = (int)(newWidth / imgAspect);
                        if (newHeight > maxHeight) { newHeight = maxHeight; newWidth = (int)(newHeight * imgAspect); }
                        this.Size = new System.Drawing.Size(newWidth, newHeight);
                        this.Location = new System.Drawing.Point(screenArea.Left + 20, screenArea.Top + 20);

                        using (var ms = new MemoryStream())
                        {
                            image.SaveAsBmp(ms);
                            ms.Position = 0;
                            _pictureBox.Image = System.Drawing.Image.FromStream(ms);
                        }
                    }
                }
                else { _host.LogError($"[QuickSheet] WARNING: Image not found at path: {imagePath}"); }
            }
            catch (Exception ex) { _host.LogError($"[QuickSheet] WARNING: Error loading image with ImageSharp: {imagePath}", ex); }

            _pinButton = new Button { Text = _isPinned ? "PIN" : "WIN", Font = new Font("Arial", 8, FontStyle.Bold), Size = new System.Drawing.Size(40, 22), Anchor = (AnchorStyles.Top | AnchorStyles.Left), Location = new System.Drawing.Point(4, 4), FlatStyle = FlatStyle.Flat, ForeColor = _isPinned ? System.Drawing.Color.White : System.Drawing.Color.Gray };
            _pinButton.FlatAppearance.BorderSize = 0;
            _pinButton.Click += PinButton_Click;
            this.Controls.Add(_pinButton);
            _pinButton.BringToFront();
            
            _toolTip = new ToolTip();
            UpdatePinButtonTooltip();
        }

        public void SetTemporaryTopMost(bool top) { if (!_isPinned) this.TopMost = top; }
        
        private void PinButton_Click(object? sender, EventArgs e) 
        { 
            _host.LogInfo("[QuickSheet] 'PIN/WIN' button clicked on a sheet form.");
            _isPinned = !_isPinned; 
            UpdateVisualPinState();
            _onPinStateChanged?.Invoke(_isPinned);
        }

        public void UpdateGlobalPinState(bool isPinned)
        {
            if (_isPinned == isPinned) return;
            _host.LogInfo($"[QuickSheet] Window received global pin state update: {isPinned}");
            _isPinned = isPinned;
            UpdateVisualPinState();
        }
        
        private void UpdateVisualPinState()
        {
            this.TopMost = _isPinned; 
            _pinButton.Text = _isPinned ? "PIN" : "WIN"; 
            _pinButton.ForeColor = _isPinned ? System.Drawing.Color.White : System.Drawing.Color.Gray; 
            UpdatePinButtonTooltip();
        }
        
        // ANGEPASST: Verwendet jetzt die Lokalisierungsfunktion
        private void UpdatePinButtonTooltip()
        {
            string tooltipText = _isPinned ? _host.T("tooltip.pin") : _host.T("tooltip.win");
            _toolTip.SetToolTip(_pinButton, tooltipText);
        }

        protected override bool ShowWithoutActivation => true;
        private const int WS_EX_NOACTIVATE = 0x08000000;
        protected override CreateParams CreateParams { get { CreateParams cp = base.CreateParams; cp.ExStyle |= WS_EX_NOACTIVATE; return cp; } }
    }
}