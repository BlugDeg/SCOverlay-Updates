using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using SCOverlay.API;

namespace SCOverlay.Addons.QuickSheet
{
    [Addon]
    public class QuickSheetAddon : IAddon
    {
        private class MenuNode { public string Name { get; set; } = ""; public string? ImagePath { get; set; } public MenuNode? Parent { get; set; } public List<MenuNode> Children { get; } = new List<MenuNode>(); }

        private IAddonHost? _host;
        private readonly List<QuickSheetForm> _openSheets = new List<QuickSheetForm>();
        private bool _areSheetsPinned = true;
        private MenuNode _rootNode = new MenuNode { Name = "Root" };
        private MenuNode _currentNode = new MenuNode { Name = "Root" };
        private bool _isControllingMenu = false;

        public string Name => "QuickSheets";
        public string Author => "SCOverlay";
        public string Version => "1.9.5"; // Finale Version

        public void Initialize(IAddonHost host)
        {
            _host = host;
            _host.LogInfo("=================================================");
            _host.LogInfo($"[QuickSheet] Initializing Addon v{Version}...");
            LoadSettings();
            BuildMenuTree();
            _currentNode = _rootNode;
            _host.LogInfo("[QuickSheet] Initialization complete.");
        }

        public IDictionary<string, (string en, string de)> GetLocalizations()
        {
            return QuickSheetLoc.Map;
        }
        
        private void OpenReadmeWindow()
        {
            if (_host == null) return;
            var readmeForm = new ReadmeForm(_host);
            // Diese Änderung erzwingt, dass das Fenster im Vordergrund bleibt.
            readmeForm.ShowDialog();
        }

        public IEnumerable<AddonButton> GetMainMenuButtons()
        {
            if (!_isControllingMenu)
            {
                // Haupt-Button im ExecHangar Menü
                yield return new AddonButton("QuickSheetRoot", () => "Quicksheets", () => {
                    _host?.LogInfo("[QuickSheet] 'Quicksheets' root button clicked. Taking menu control.");
                    _isControllingMenu = true;
                    _currentNode = _rootNode;
                    _host?.TakeMenuControl(this, GoBack);
                });
            }
            else
            {
                // Liste alle Ordner und Bilder im aktuellen Verzeichnis
                foreach (var node in _currentNode.Children)
                {
                    Action onClick = node.ImagePath != null
                        ? (Action)(() => OpenSheet(node.ImagePath!))
                        : () => {
                            _host?.LogInfo($"[QuickSheet] Navigating to menu node: {node.Name}");
                            _currentNode = node;
                            _host?.TakeMenuControl(this, GoBack);
                        };
                    yield return new AddonButton(node.Name, () => node.Name, onClick);
                }
                
                if (_currentNode == _rootNode)
                {
                    yield return new AddonButton("QuickSheetReadme", () => _host?.T("quicksheet.menu.readme") ?? "Readme", OpenReadmeWindow);
                }
            }
        }

        private void LoadSettings() { if (_host == null) return; _host.LogInfo("[QuickSheet] Loading settings..."); _areSheetsPinned = bool.Parse(_host.GetSetting("QuickSheet_AreSheetsPinned", "true")); }
        private void SaveSettings() { if (_host == null) return; _host.LogInfo("[QuickSheet] Saving settings..."); _host.SetSetting("QuickSheet_AreSheetsPinned", _areSheetsPinned.ToString()); }
        private void GoBack() { if (_currentNode == _rootNode || _currentNode.Parent == null) { _isControllingMenu = false; _host?.ReleaseMenuControl(); } else { _currentNode = _currentNode.Parent; _host?.TakeMenuControl(this, GoBack); } }
        private void OnSheetPinStateChanged(bool newState) { if (_areSheetsPinned == newState) return; _areSheetsPinned = newState; SaveSettings(); foreach (var sheet in _openSheets) { sheet.UpdateGlobalPinState(newState); } }
        private void OpenSheet(string imagePath) { if (_host is null) return; var sheetForm = new QuickSheetForm(imagePath, _host, _areSheetsPinned, OnSheetPinStateChanged); sheetForm.FormClosed += (s, e) => _openSheets.Remove(sheetForm); _openSheets.Add(sheetForm); sheetForm.Show(); }
        public void OnOverlayVisibilityChanged(bool isVisible) { if (!isVisible) { _isControllingMenu = false; _currentNode = _rootNode; } foreach (var sheet in _openSheets) { bool shouldBeVisible = sheet.IsPinned || isVisible; if (shouldBeVisible && !sheet.Visible) sheet.Show(); if (!shouldBeVisible && sheet.Visible) sheet.Hide(); sheet.SetTemporaryTopMost(isVisible); if (isVisible) sheet.BringToFront(); } }
        public void Shutdown() { foreach (var sheet in _openSheets.ToList()) sheet.Close(); }
        public void Draw(Graphics g, Rectangle bounds) { }
        public IEnumerable<AddonControl> GetSettingsControls() => new List<AddonControl>();
        private void BuildMenuTree() { try { string? addonDirectory = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location); if (string.IsNullOrEmpty(addonDirectory)) { _host?.LogError("[QuickSheet] CRITICAL: Could not determine addon directory path."); return; } string sheetPath = Path.Combine(addonDirectory, "sheets"); if (!Directory.Exists(sheetPath)) { return; } _rootNode = new MenuNode { Name = "Root" }; PopulateNode(_rootNode, sheetPath); } catch (Exception ex) { _host?.LogError("[QuickSheet] WARNING: Failed to build menu tree.", ex); } }
        private void PopulateNode(MenuNode parentNode, string path) { foreach (var dir in Directory.GetDirectories(path).OrderBy(d => d)) { string dirName = Path.GetFileName(dir); var imageFiles = Directory.GetFiles(dir, "*.png").Concat(Directory.GetFiles(dir, "*.jpg")).ToList(); var subDirs = Directory.GetDirectories(dir); if (imageFiles.Count == 1 && !subDirs.Any() && string.Equals(Path.GetFileNameWithoutExtension(imageFiles[0]), dirName, StringComparison.OrdinalIgnoreCase)) { var shortcutNode = new MenuNode { Name = dirName, ImagePath = imageFiles[0], Parent = parentNode }; parentNode.Children.Add(shortcutNode); } else { var branchNode = new MenuNode { Name = dirName, Parent = parentNode }; parentNode.Children.Add(branchNode); PopulateNode(branchNode, dir); } } foreach (var file in Directory.GetFiles(path, "*.png").Concat(Directory.GetFiles(path, "*.jpg")).OrderBy(f => f)) { var leafNode = new MenuNode { Name = Path.GetFileNameWithoutExtension(file), ImagePath = file, Parent = parentNode }; parentNode.Children.Add(leafNode); } }
    }
}