// /SpyCitizenAddon/PlayerSighting.cs

using System;

namespace SCOverlay.Addons.SpyCitizen
{
    // Diese Definition ist jetzt für alle Klassen im Namespace sichtbar.
    public record PlayerSighting(string Name, DateTime Timestamp);
}