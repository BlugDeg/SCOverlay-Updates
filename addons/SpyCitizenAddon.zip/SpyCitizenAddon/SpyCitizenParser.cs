// /SpyCitizenAddon/SpyCitizenParser.cs (KORRIGIERT)

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace SCOverlay.Addons.SpyCitizen
{
    public static class SpyCitizenParser
    {
        public record KillEvent(string Victim, string Killer, string Weapon, string DamageType, DateTime Timestamp);
        public record SessionInfo(string? Ip, string? ShardId, string? ClientSessionId);

        private static readonly Regex SimplePlayerRe = new Regex(@"<(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z)>.*?Player: ([^,]+?),", RegexOptions.Compiled);
        private static readonly Regex KillEventRe = new Regex(@"<(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z)>.*?CActor::Kill: '([^']+)'.*?killed by '([^']+)'.*?using '([^']+)'.*?with damage type '([^']+)'.*", RegexOptions.Compiled);
        
        // KORREKTUR: Die Strings sind jetzt als verbatim (@"...") markiert, um die Backslashes korrekt zu interpretieren.
        private static readonly Regex JoinMatchRe = new Regex(@"\[Notice\] <Join Match> address\[([^\]]+)\]", RegexOptions.Compiled);
        private static readonly Regex RequestConnectRe = new Regex(@"\[Notice\] <Session Manager \[Request Connect\]> Connecting ([^:]+):", RegexOptions.Compiled);
        private static readonly Regex ShardIdRe = new Regex(@"\[Notice\] <Update Shard Id> New Shard Id: (.*)", RegexOptions.Compiled);
        private static readonly Regex ClientSessionIdRe = new Regex(@"\[Trace\] @session: '([^']+)'", RegexOptions.Compiled);
        
        private static readonly HashSet<string> NpcIgnoreSubstrings = new HashSet<string> { "npc", "kopion", "state", "local_shard", "unknown", "ai", "ninetails", "train", "tram", "transport", "security", "stantonbois", "pirate", "ekart", "tec_", "outlaw", "atc_", "atc", "cargo_", "civ_", "uee_", "alpha_", "corpse", "<local client>", "local client", "manager", "communication", "ai_module", "gamecode", "placeholder", "unavailable", "partymembermarker", "spawnpoint", "bed_hospital", "idlespot_counter", "hawker", "asyncqueryinventory", "loadfromxmlnode", "loadingplatformmanager", "transitcarriage", "objectmarker", "transitmanager", "crus_", "anvl_", "misc_", "grin_", "rsi_", "aegs_", "argo_", "aur_", "bdry_", "carr_", "cno_", "cod_", "drak_", "espr_", "gatr_", "mpu_", "orig_", "ptr_", "rmc_", "scoe_", "tl_obj_", "ts_char_", "ts_game_", "ts_misc_", "turret_", "ship", "vehicle", "entity", "ui_entity", "unattendedvehiclemarker", "streamingsoc", "jumppoint", "entityattachment", "jumptunnelhost", "fuelcontroller", "default_", "physarea", "geom", "entitygrid", "physics instance stats", "console user", "missionobjectivemarker", "ownerless", "playbackcontroller", "entity component", "clandingarea", "wallet", "cwallet", "service", "endpoint", "entitlement", "telemetry", "entitysystem", "cryanimation", "hospital", "rwes", "gameplaycontroller", "connection flow", "actor stall", "charactercreate", "team_transitsystem", "team_missionfeatures", "team_security", "team_pu_combat", "team_spawn", "team_environment", "team_gameobject", "team_spawning", "team_pawn", "vlk_" };

        public static bool TryParsePlayer(string line, out PlayerSighting? sighting)
        {
            sighting = null;
            var match = SimplePlayerRe.Match(line);
            if (match.Success)
            {
                string timestampStr = match.Groups[1].Value;
                string rawName = match.Groups[2].Value;
                
                string playerName = rawName.Trim();

                if (!string.IsNullOrWhiteSpace(playerName) && playerName.Length > 2 && !IsNpcOrSystem(playerName) && DateTime.TryParse(timestampStr, out var timestamp))
                {
                    sighting = new PlayerSighting(playerName, timestamp);
                    return true;
                }
            }
            return false;
        }
        
        public static bool TryParseKillEvent(string line, out KillEvent? kill)
        {
            kill = null;
            var match = KillEventRe.Match(line);
            if (match.Success)
            {
                string timestampStr = match.Groups[1].Value;
                string victim = match.Groups[2].Value;
                string killer = match.Groups[3].Value;
                string weapon = match.Groups[4].Value;
                string damageType = match.Groups[5].Value;

                if (!string.IsNullOrWhiteSpace(victim) && !string.IsNullOrWhiteSpace(killer) &&
                    !IsNpcOrSystem(victim) && !IsNpcOrSystem(killer) &&
                    DateTime.TryParse(timestampStr, out var timestamp))
                {
                    kill = new KillEvent(victim.Trim(), killer.Trim(), weapon.Trim(), damageType.Trim(), timestamp);
                    return true;
                }
            }
            return false;
        }

        public static bool TryParseServerIp(string line, out string? ip)
        {
            ip = null;
            var match = JoinMatchRe.Match(line);
            if (!match.Success)
            {
                match = RequestConnectRe.Match(line);
            }

            if (match.Success)
            {
                string foundIp = match.Groups[1].Value;
                if (foundIp != "<local>" && foundIp != "127.0.0.1")
                {
                    ip = foundIp;
                    return true;
                }
            }
            return false;
        }

        public static bool TryParseShardId(string line, out string? shardId)
        {
            shardId = null;
            var match = ShardIdRe.Match(line);
            if (match.Success)
            {
                shardId = match.Groups[1].Value.Trim();
                return true;
            }
            return false;
        }

        public static bool TryParseClientSessionId(string line, out string? sessionId)
        {
            sessionId = null;
            var match = ClientSessionIdRe.Match(line);
            if (match.Success)
            {
                sessionId = match.Groups[1].Value;
                return true;
            }
            return false;
        }
        
        private static bool IsNpcOrSystem(string name)
        {
            if (string.IsNullOrEmpty(name)) return true;
            string nameLower = name.ToLowerInvariant();
            if (NpcIgnoreSubstrings.Any(sub => nameLower.Contains(sub))) return true;
            return false;
        }
    }
}