// /SCOverlay.Addons.SpyCitizen/SpyCitizenAddon.cs (KOMPLETTE DATEI)

using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using SCOverlay.API;
using static SCOverlay.Addons.SpyCitizen.SpyCitizenParser;

namespace SCOverlay.Addons.SpyCitizen
{
    // ================================================================
    // ===== HIER IST DIE ÄNDERUNG =====
    // ================================================================
    [Addon(LicenseId = "SpyCitizen")]
    public class SpyCitizenAddon : IAddon
    {
        private enum MenuState { Root, Main, Settings, MonitorSettings, HudSettings, Sounds, Account }
        private enum SoundMenuState { Main, EditingUnknown, EditingHostile, EditingOrga, EditingFriendly }
        private IAddonHost? _host;
        private SpyCitizenForm? _monitorForm;
        private HudAlertForm? _hudAlertForm;
        private SpyCitizenService? _service;
        private readonly SpyCitizenDB _db = new SpyCitizenDB();
        private bool _isServiceRunning = true;
        private bool _isWindowVisible = false;
        private bool _isOverlayVisible = false;
        private bool _isHudAlertActive = true;
        private MenuState _currentMenuState = MenuState.Root;
        private SoundMenuState _currentSoundMenuState = SoundMenuState.Main;
        public bool IsOrgaScraperEnabled { get; private set; } = true;
        
        private int _hudMonitorIndex = 0;
        private HudPosition _hudPosition = HudPosition.TopCenter;
        private readonly List<HudPosition> _allHudPositions = Enum.GetValues(typeof(HudPosition)).Cast<HudPosition>().ToList();
        
        private float _soundVolume = 1.0f;
        private bool _isMonitorInAppMode = false;

        public string Name => "SpyCitizen";
        public string Author => "Gemini & SCOverlay";
        public string Version => "3.2_API";

        public void Initialize(IAddonHost host)
        {
            _host = host;
            _host.LogInfo("=================================================");
            _host.LogInfo($"[SpyCitizen] Initializing Addon v{Version}...");

            _service = new SpyCitizenService(_host);
            _db.InitializeDatabase();

            _host.LogInfo("[SpyCitizen] Loading all settings from host...");
            string ingameName = host.GetSetting("SpyCitizen_IngameName", string.Empty);
            _isHudAlertActive = bool.Parse(host.GetSetting("SpyCitizen_HudAlertActive", "true"));
            _hudMonitorIndex = int.Parse(host.GetSetting("SpyCitizen_HudMonitor", "0"));
            _hudPosition = Enum.TryParse<HudPosition>(host.GetSetting("SpyCitizen_HudPosition", "TopCenter"), out var pos) ? pos : HudPosition.TopCenter;
            IsOrgaScraperEnabled = bool.Parse(host.GetSetting("SpyCitizen_OrgaScraperEnabled", "true"));
            _isServiceRunning = bool.Parse(host.GetSetting("SpyCitizen_ServiceRunning", "true"));
            _soundVolume = float.Parse(host.GetSetting("SpyCitizen_SoundVolume", "1.0"), CultureInfo.InvariantCulture);
            _isMonitorInAppMode = bool.Parse(host.GetSetting("SpyCitizen_MonitorAppMode", "false"));
            
            _monitorForm = new SpyCitizenForm(this, ingameName, _host, _isMonitorInAppMode);
            _monitorForm.UserClosedWindow += OnMonitorFormClosedByUser;
            
            _hudAlertForm = new HudAlertForm();
            _hudAlertForm.Show();
            _hudAlertForm.RepositionHud(_hudMonitorIndex, _hudPosition);
            _hudAlertForm.Hide();

            _monitorForm.LoadInitialData();
            _monitorForm.UpdateSessionInfo("N/A", "N/A", "N/A");
            
            _service.OnPlayerSighted += HandlePlayerSighted;
            _service.OnKillEvent += HandleKillEvent;
            _service.OnSessionChanged += HandleSessionChanged;
            
            string? logPath = host.GetSetting("SpyCitizen_LogPath", string.Empty);
            if (_isServiceRunning)
            {
                if (!string.IsNullOrEmpty(logPath) && File.Exists(logPath))
                {
                    _service.StartMonitoring(logPath);
                } 
                else 
                {
                    _isServiceRunning = false;
                    _host.LogError($"[SpyCitizen] WARNING: Log path not set or file does not exist. Scan will not start automatically.");
                }
            }
            _host.LogInfo("[SpyCitizen] Initialization complete.");
        }

        public IDictionary<string, (string en, string de)> GetLocalizations()
        {
            return SpyCitizenLoc.Map;
        }

        private void OpenReadmeWindow()
        {
            if (_host == null) return;
            var readmeForm = new ReadmeForm(_host);
            readmeForm.ShowDialog();
        }
        
        private void OnMonitorFormClosedByUser()
        {
            _host?.LogInfo("[SpyCitizen] Monitor window was closed by user via 'X'. Setting internal visibility state to false.");
            _isWindowVisible = false;
        }

        private void HandleSessionChanged(SessionInfo newSession)
        {
            if (_host == null) return;
            string lastKnownIp = _db.GetSetting("last_known_ip", string.Empty);
            if (newSession.Ip != null && newSession.Ip != lastKnownIp)
            {
                _host.LogInfo("[SpyCitizen] New server detected. Clearing 'Players Today' list.");
                _db.SetSetting("last_known_ip", newSession.Ip);
                if(newSession.ShardId != null) _db.SetSetting("last_known_shard_id", newSession.ShardId);
                if(newSession.ClientSessionId != null) _db.SetSetting("client_session_id", newSession.ClientSessionId);
                _monitorForm?.ClearPlayersToday();
                _monitorForm?.UpdateSessionInfo(newSession.Ip ?? "N/A", newSession.ShardId ?? "N/A", newSession.ClientSessionId ?? "N/A");
            }
        }

        private void HandlePlayerSighted(PlayerSighting sighting)
        {
            if (_host == null) return;
            
            string ingameName = _host.GetSetting("SpyCitizen_IngameName", string.Empty);
            if (!string.IsNullOrEmpty(ingameName) && sighting.Name.Equals(ingameName, StringComparison.OrdinalIgnoreCase))
            {
                _host.LogInfo($"[SpyCitizen] Ignored sighting of own player: {sighting.Name}");
                return;
            }

            var playerInfo = _db.AddOrUpdatePlayerSighting(sighting);
            if (playerInfo == null) return;
            _monitorForm?.AddOrUpdatePlayer(playerInfo);
            
            if (_isHudAlertActive) _hudAlertForm?.ShowAlert(playerInfo.Name, playerInfo.Category);

            string settingKey = $"SpyCitizen_{playerInfo.Category}AlertSoundPath";
            string? soundPath = _host.GetSetting(settingKey, string.Empty);
            if (!string.IsNullOrEmpty(soundPath))
            {
                if (File.Exists(soundPath)) _host.Sound.PlayFile(soundPath, _soundVolume);
                else _host.LogError($"[SpyCitizen] WARNING: Sound file configured for category '{playerInfo.Category}' was not found at path: '{soundPath}'.");
            }
        }
        
        private void HandleKillEvent(KillEvent kill)
        {
            if (_host == null) return;
            string ingameName = _host.GetSetting("SpyCitizen_IngameName", string.Empty);
            _db.ProcessKillEvent(kill, ingameName);
            _monitorForm?.TriggerStatisticsRefresh();

            if (_isHudAlertActive && kill.Killer.Equals(ingameName, StringComparison.OrdinalIgnoreCase))
            {
                var victimInfo = _db.GetPlayer(kill.Victim);
                _hudAlertForm?.ShowKillConfirmation(kill.Victim, victimInfo?.Category ?? "N/A");
            }
        }

        public IEnumerable<AddonButton> GetMainMenuButtons()
        {
            if (_host == null) yield break;
            
            switch (_currentMenuState)
            {
                case MenuState.Root:
                    yield return new AddonButton("SpyCitizenRoot", () => "SpyCitizen", () => { _currentMenuState = MenuState.Main; _host.TakeMenuControl(this, GoBack); });
                    break;
                case MenuState.Main:
                    yield return new AddonButton("SpyCitizenToggleWindow", () => "Monitor", ToggleWindowVisibility);
                    yield return new AddonButton("SpyCitizenToggleService", () => _isServiceRunning ? "Scan: ON" : "Scan: OFF", ToggleService);
                    yield return new AddonButton("SpyCitizenSettings", () => _host.T("page.settings"), () => { _currentMenuState = MenuState.Settings; _host.TakeMenuControl(this, GoBack); });
                    yield return new AddonButton("SpyCitizenReadme", () => _host.T("spycitizen.menu.readme"), OpenReadmeWindow);
                    break;
                case MenuState.Settings:
                    yield return new AddonButton("SpyCitizenMonitorSettings", () => "Monitor Settings", () => { _currentMenuState = MenuState.MonitorSettings; _host.TakeMenuControl(this, GoBack); });
                    yield return new AddonButton("SpyCitizenHudSettings", () => "HUD Settings", () => { _currentMenuState = MenuState.HudSettings; _host.TakeMenuControl(this, GoBack); });
                    yield return new AddonButton("SpyCitizenSounds", () => _host.T("spycitizen.sounds"), () => { _currentMenuState = MenuState.Sounds; _currentSoundMenuState = SoundMenuState.Main; _host.TakeMenuControl(this, GoBack); });
                    yield return new AddonButton("SpyCitizenAccount", () => _host.T("spycitizen.account"), () => { _currentMenuState = MenuState.Account; _host.TakeMenuControl(this, GoBack); });
                    break;
                case MenuState.MonitorSettings:
                    yield return new AddonButton("SpyCitizenToggleAppMode", () => $"Application Mode: {(_isMonitorInAppMode ? _host.T("generic.on") : _host.T("generic.off"))}", ToggleApplicationMode);
                    yield return new AddonButton("SpyCitizenToggleOrgaScraper", () => string.Format(_host.T("spycitizen.orgaScraperToggle"), IsOrgaScraperEnabled ? _host.T("generic.on") : _host.T("generic.off")), ToggleOrgaScraper);
                    break;
                case MenuState.HudSettings:
                    yield return new AddonButton("SpyCitizenToggleHud", () => $"{_host.T("spycitizen.hudAlert")}: {(_isHudAlertActive ? _host.T("generic.on") : _host.T("generic.off"))}", ToggleHudAlert);
                    yield return new AddonButton("SpyCitizenCycleHudMonitor", () => $"Monitor: {_hudMonitorIndex + 1} / {Screen.AllScreens.Length}", CycleHudMonitor);
                    yield return new AddonButton("SpyCitizenCycleHudPosition", () => $"Position: {_hudPosition}", CycleHudPosition);
                    break;
                case MenuState.Sounds:
                    switch (_currentSoundMenuState)
                    {
                        case SoundMenuState.Main:
                            yield return new AddonButton("SpyCitizenChangeVolume", () => $"Volume: {_soundVolume:P0}", ChangeSoundVolume);
                            yield return new AddonButton("SpyCitizenEditUnknownSound", () => "Unknown Sound Settings", () => { _currentSoundMenuState = SoundMenuState.EditingUnknown; _host.TakeMenuControl(this, GoBack); });
                            yield return new AddonButton("SpyCitizenEditHostileSound", () => "Hostile Sound Settings", () => { _currentSoundMenuState = SoundMenuState.EditingHostile; _host.TakeMenuControl(this, GoBack); });
                            yield return new AddonButton("SpyCitizenEditOrgaSound", () => "Orga Sound Settings", () => { _currentSoundMenuState = SoundMenuState.EditingOrga; _host.TakeMenuControl(this, GoBack); });
                            yield return new AddonButton("SpyCitizenEditFriendlySound", () => "Friendly Sound Settings", () => { _currentSoundMenuState = SoundMenuState.EditingFriendly; _host.TakeMenuControl(this, GoBack); });
                            break;
                        case SoundMenuState.EditingUnknown:
                            yield return new AddonButton("SpyCitizenSetUnknownSound", () => _host.T("spycitizen.setUnknownAlert"), () => OpenSoundFileDialog("SpyCitizen_UnknownAlertSoundPath"));
                            yield return new AddonButton("SpyCitizenResetUnknownSound", () => "Reset Unknown", () => ResetSoundSetting("SpyCitizen_UnknownAlertSoundPath"));
                            break;
                        case SoundMenuState.EditingHostile:
                             yield return new AddonButton("SpyCitizenSetHostileSound", () => _host.T("spycitizen.setHostileAlert"), () => OpenSoundFileDialog("SpyCitizen_HostileAlertSoundPath"));
                             yield return new AddonButton("SpyCitizenResetHostileSound", () => "Reset Hostile", () => ResetSoundSetting("SpyCitizen_HostileAlertSoundPath"));
                            break;
                        case SoundMenuState.EditingOrga:
                             yield return new AddonButton("SpyCitizenSetOrgaSound", () => _host.T("spycitizen.setOrgaAlert"), () => OpenSoundFileDialog("SpyCitizen_OrgaAlertSoundPath"));
                             yield return new AddonButton("SpyCitizenResetOrgaSound", () => "Reset Orga", () => ResetSoundSetting("SpyCitizen_OrgaAlertSoundPath"));
                            break;
                        case SoundMenuState.EditingFriendly:
                             yield return new AddonButton("SpyCitizenSetFriendlySound", () => _host.T("spycitizen.setFriendlyAlert"), () => OpenSoundFileDialog("SpyCitizen_FriendlyAlertSoundPath"));
                             yield return new AddonButton("SpyCitizenResetFriendlySound", () => "Reset Friendly", () => ResetSoundSetting("SpyCitizen_FriendlyAlertSoundPath"));
                            break;
                    }
                    break;
                case MenuState.Account:
                    yield return new AddonButton("SpyCitizenSetIngameName", () => _host.T("spycitizen.setIngameName"), OpenIngameNameDialog);
                    yield return new AddonButton("SpyCitizenSetLogPath", () => _host.T("spycitizen.setLogPath"), OpenLogPathDialog);
                    break;
            }
        }
        
        private void ToggleApplicationMode()
        {
            if (_host == null) return;
            _isMonitorInAppMode = !_isMonitorInAppMode;
            _host.SetSetting("SpyCitizen_MonitorAppMode", _isMonitorInAppMode.ToString());
            _monitorForm?.SetApplicationMode(_isMonitorInAppMode);
            _host.Window.ShowNotification($"Monitor Application Mode: {(_isMonitorInAppMode ? "ON" : "OFF")}");
            _host.TakeMenuControl(this, GoBack);
        }

        private void ChangeSoundVolume()
        {
            if (_host == null) return;
            _soundVolume += 0.1f;
            if (_soundVolume > 1.01f) _soundVolume = 0.0f;
            _host.SetSetting("SpyCitizen_SoundVolume", _soundVolume.ToString(CultureInfo.InvariantCulture));
            _host.Window.ShowNotification($"Sound Volume: {_soundVolume:P0}");
            _host.TakeMenuControl(this, GoBack);
        }

        private void ResetSoundSetting(string key)
        {
            if (_host == null) return;
            _host.SetSetting(key, string.Empty);
            _host.Window.ShowNotification($"Sound for '{key.Replace("SpyCitizen_", "").Replace("AlertSoundPath","")}' has been reset.");
            _host.TakeMenuControl(this, GoBack);
        }

        private void CycleHudMonitor()
        {
            if (_host == null) return;
            int screenCount = Screen.AllScreens.Length;
            _hudMonitorIndex = (_hudMonitorIndex + 1) % screenCount;
            _host.SetSetting("SpyCitizen_HudMonitor", _hudMonitorIndex.ToString());
            _hudAlertForm?.RepositionHud(_hudMonitorIndex, _hudPosition);
            _host.Window.ShowNotification($"HUD Monitor: {_hudMonitorIndex + 1}");
            _host.TakeMenuControl(this, GoBack);
        }

        private void CycleHudPosition()
        {
            if (_host == null) return;
            int currentIndex = _allHudPositions.IndexOf(_hudPosition);
            _hudPosition = _allHudPositions[(currentIndex + 1) % _allHudPositions.Count];
            _host.SetSetting("SpyCitizen_HudPosition", _hudPosition.ToString());
            _hudAlertForm?.RepositionHud(_hudMonitorIndex, _hudPosition);
            _host.Window.ShowNotification($"HUD Position: {_hudPosition}");
            _host.TakeMenuControl(this, GoBack);
        }

        private void ToggleOrgaScraper()
        {
            if (_host == null) return;
            IsOrgaScraperEnabled = !IsOrgaScraperEnabled;
            _host.SetSetting("SpyCitizen_OrgaScraperEnabled", IsOrgaScraperEnabled.ToString());
            using (var dialog = new OrgaInfoDialog(_host))
            {
                dialog.ShowDialog();
            }
        }

        private void ToggleHudAlert()
        {
            if (_host == null) return;
            _isHudAlertActive = !_isHudAlertActive;
            _host.SetSetting("SpyCitizen_HudAlertActive", _isHudAlertActive.ToString());
            _host.Window.ShowNotification($"HUD Alert: {(_isHudAlertActive ? "On" : "Off")}");
            if (!_isHudAlertActive) _hudAlertForm?.ClearAndHide();
        }
        
        private void OpenIngameNameDialog()
        {
            if (_host == null) return;
            string currentName = _host.GetSetting("SpyCitizen_IngameName", string.Empty);
            using (var dialog = new IngameNameDialog(currentName))
            {
                if (dialog.ShowDialog(_host.Window as IWin32Window) == DialogResult.OK)
                {
                    _host.SetSetting("SpyCitizen_IngameName", dialog.IngameName);
                    _monitorForm?.SetIngameName(dialog.IngameName);
                    _host.Window.ShowNotification($"In-game name set to: {dialog.IngameName}");
                }
            }
        }

        private void ToggleWindowVisibility() { _isWindowVisible = !_isWindowVisible; UpdateMonitorFormVisibility(); }
        
        private void ToggleService()
        {
            if (_host == null) return;
            _isServiceRunning = !_isServiceRunning;
            _host.SetSetting("SpyCitizen_ServiceRunning", _isServiceRunning.ToString());
            string? logPath = _host.GetSetting("SpyCitizen_LogPath", string.Empty);

            if (_isServiceRunning)
            {
                if (!string.IsNullOrEmpty(logPath))
                {
                    _service?.StartMonitoring(logPath);
                    _host.Window.ShowNotification("SpyCitizen Scan: STARTED");
                }
                else
                {
                    _host.LogError("[SpyCitizen] WARNING: Cannot start scan because log path is not set.");
                    _host.Window.ShowNotification("SpyCitizen Scan: FAILED (No log path)");
                }
            }
            else
            {
                _service?.StopMonitoring();
                _host.Window.ShowNotification("SpyCitizen Scan: STOPPED");
            }
        }
        
        private void GoBack() 
        { 
            if (_host == null) return;
            
            if (_currentMenuState == MenuState.Sounds && _currentSoundMenuState != SoundMenuState.Main)
            {
                _currentSoundMenuState = SoundMenuState.Main;
                _host.TakeMenuControl(this, GoBack);
                return;
            }

            if (_currentMenuState == MenuState.MonitorSettings || _currentMenuState == MenuState.HudSettings || _currentMenuState == MenuState.Sounds || _currentMenuState == MenuState.Account) _currentMenuState = MenuState.Settings;
            else if (_currentMenuState == MenuState.Settings) _currentMenuState = MenuState.Main; 
            else { _currentMenuState = MenuState.Root; _host.ReleaseMenuControl(); return; } 
            
            _host.TakeMenuControl(this, GoBack); 
        }

        private void OpenLogPathDialog()
        {
            if (_host == null) return;
            using (var d = new OpenFileDialog { Title = "Select Star Citizen Game.log", Filter = "Log Files|Game.log|All Files|*.*" })
            {
                if (d.ShowDialog(_host.Window as IWin32Window) == DialogResult.OK)
                {
                    _host.SetSetting("SpyCitizen_LogPath", d.FileName);
                    _service?.StopMonitoring();
                    if (_isServiceRunning) _service?.StartMonitoring(d.FileName);
                    _host.Window.ShowNotification($"SpyCitizen log path set:\n{d.FileName}");
                }
            }
        }

        private void OpenSoundFileDialog(string key)
        {
            if (_host == null) return;
            using (var d = new OpenFileDialog { Title = "Select Alert Sound", Filter = "Sound Files|*.wav|All Files|*.*" })
            {
                if (d.ShowDialog(_host.Window as IWin32Window) == DialogResult.OK)
                {
                    _host.SetSetting(key, d.FileName);
                    _host.Window.ShowNotification($"Alert sound set:\n{Path.GetFileName(d.FileName)}");
                }
            }
        }
        
        public void OnOverlayVisibilityChanged(bool isVisible) 
        { 
            _isOverlayVisible = isVisible; 
            if (!isVisible) 
            {
                _currentMenuState = MenuState.Root; 
                _currentSoundMenuState = SoundMenuState.Main;
            }
            UpdateMonitorFormVisibility(); 
        }
        
        private void UpdateMonitorFormVisibility()
        {
            if (_monitorForm == null || _host == null) return;
            bool shouldBeVisible = _isWindowVisible && (_isMonitorInAppMode || _monitorForm.IsPinned || _isOverlayVisible);
            if (shouldBeVisible)
            {
                if (!_monitorForm.Visible) 
                {
                    _host.LogInfo("[SpyCitizen] Monitor form is about to be shown. Applying/refreshing translations.");
                    _monitorForm.UpdateUITranslations();
                }
                if (!_monitorForm.Visible) _monitorForm.Show();
                _monitorForm.BringToFront();
            }
            else
            {
                if (_monitorForm.Visible) _monitorForm.Hide();
            }
        }
        
        public void Shutdown() 
        { 
            _service?.StopMonitoring(); 
            _monitorForm?.Close();
            _hudAlertForm?.Dispose(); 
        }
        
        public void Draw(Graphics g, Rectangle bounds) { }
        public IEnumerable<AddonControl> GetSettingsControls() => new List<AddonControl>();
    }

    internal class IngameNameDialog : Form
    {
        public string IngameName => _nameTextBox.Text;
        private readonly TextBox _nameTextBox;
        public IngameNameDialog(string currentName)
        {
            this.Text = "Set In-game Name";
            this.Size = new Size(300, 120);
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.StartPosition = FormStartPosition.CenterParent;
            this.ShowInTaskbar = false;
            this.TopMost = true;
            var label = new Label { Text = "Enter your full in-game name:", AutoSize = true, Location = new Point(10, 10) };
            _nameTextBox = new TextBox { Text = currentName, Location = new Point(10, 35), Width = 260 };
            var saveButton = new Button { Text = "Save", DialogResult = DialogResult.OK, Location = new Point(195, 60) };
            this.Controls.AddRange(new Control[] { label, _nameTextBox, saveButton });
            this.AcceptButton = saveButton;
        }
    }
}