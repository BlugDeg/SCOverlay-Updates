// /SpyCitizenAddon/OrgaScraperService.cs (FINALE, API-KOMPATIBLE VERSION)

using System;
using System.Collections.Concurrent;
using System.IO;
using System.Net.Http;
using System.Threading.Tasks;
using SixLabors.ImageSharp.Processing;
using HAP = HtmlAgilityPack;
using SCOverlay.API; // NUTZT JETZT DIE SAUBERE API

namespace SCOverlay.Addons.SpyCitizen
{
    public record OrgaInfo(string? Name, string? Sid, SixLabors.ImageSharp.Image? Logo, string? OrgaUrl);

    public static class OrgaScraperService
    {
        private static readonly HttpClient _httpClient = new HttpClient();
        private static readonly ConcurrentDictionary<string, byte[]> _imageCache = new ConcurrentDictionary<string, byte[]>();
        private const string RsiBaseUrl = "https://robertsspaceindustries.com";

        // Die Methode erwartet jetzt den 'host', um loggen zu können.
        public static async Task<OrgaInfo> GetOrgaInfoAsync(string playerName, IAddonHost host)
        {
            try
            {
                string profileUrl = $"{RsiBaseUrl}/citizens/{Uri.EscapeDataString(playerName)}";
                
                var requestMessage = new HttpRequestMessage(HttpMethod.Get, profileUrl);
                requestMessage.Headers.UserAgent.ParseAdd("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36");
                requestMessage.Headers.Accept.ParseAdd("text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8");
                requestMessage.Headers.AcceptLanguage.ParseAdd("en-US,en;q=0.9");
                requestMessage.Headers.Referrer = new Uri(RsiBaseUrl + "/");

                var response = await _httpClient.SendAsync(requestMessage);

                if (!response.IsSuccessStatusCode)
                {
                    if (response.StatusCode == System.Net.HttpStatusCode.NotFound)
                    {
                        return new OrgaInfo("Player not found", null, null, null);
                    }
                    response.EnsureSuccessStatusCode();
                }
                
                string html = await response.Content.ReadAsStringAsync();
                var doc = new HAP.HtmlDocument();
                doc.LoadHtml(html);

                var mainOrgaNode = doc.DocumentNode.SelectSingleNode("//div[contains(@class, 'main-org')]");

                if (mainOrgaNode == null)
                {
                    return new OrgaInfo("N/A", null, null, null);
                }
                
                var linkNode = mainOrgaNode.SelectSingleNode(".//a[contains(@class, 'value')]");
                var imgNode = mainOrgaNode.SelectSingleNode(".//img");

                if (linkNode == null)
                {
                     return new OrgaInfo("N/A", null, null, null);
                }

                string? orgaName = linkNode.InnerText.Trim();
                string? orgaSid = mainOrgaNode.SelectSingleNode(".//p[span[contains(text(), 'Spectrum Identification (SID)')]]/strong")?.InnerText.Trim();
                string? logoRelativeUrl = imgNode?.GetAttributeValue("src", null);
                string? orgaRelativeUrl = linkNode.GetAttributeValue("href", null);

                if (string.IsNullOrEmpty(logoRelativeUrl))
                {
                    return new OrgaInfo(orgaName, orgaSid, null, orgaRelativeUrl);
                }
                
                string logoAbsoluteUrl = logoRelativeUrl.StartsWith("http") ? logoRelativeUrl : RsiBaseUrl + logoRelativeUrl;
                
                byte[] imageData;
                if (_imageCache.TryGetValue(logoAbsoluteUrl, out var cachedImageData))
                {
                    imageData = cachedImageData;
                }
                else
                {
                    imageData = await _httpClient.GetByteArrayAsync(logoAbsoluteUrl);
                    _imageCache.TryAdd(logoAbsoluteUrl, imageData);
                }

                using (var ms = new MemoryStream(imageData))
                {
                    var image = await SixLabors.ImageSharp.Image.LoadAsync(ms);
                    image.Mutate(x => x.Resize(new ResizeOptions
                    {
                        Size = new SixLabors.ImageSharp.Size(64, 64),
                        Mode = ResizeMode.Max
                    }));
                    return new OrgaInfo(orgaName, orgaSid, image, orgaRelativeUrl);
                }
            }
            catch (HttpRequestException httpEx)
            {
                // Alle DebugLog-Aufrufe wurden durch host.Log... ersetzt.
                host.LogError($"[OrgaScraperService] HTTP Fehler: {httpEx.StatusCode} für Spieler {playerName}.", httpEx);
                return new OrgaInfo("Error (HTTP)", null, null, null);
            }
            catch (Exception ex)
            {
                host.LogError($"[OrgaScraperService] Schwerwiegender Fehler beim Scrapen für Spieler {playerName}.", ex);
                return new OrgaInfo("Error", null, null, null);
            }
        }
    }
}