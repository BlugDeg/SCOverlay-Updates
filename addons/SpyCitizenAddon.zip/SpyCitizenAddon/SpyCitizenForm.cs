using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using SCOverlay.API;

namespace SCOverlay.Addons.SpyCitizen
{
    public class SpyCitizenForm : Form
    {
        public event Action? UserClosedWindow;

        private readonly IAddonHost _host;
        private enum MonitorView { Players, History, MyDeaths, MyKills, Statistics }
        private MonitorView _currentView = MonitorView.Players;

        private readonly SpyCitizenDB _db = new SpyCitizenDB();
        private readonly DataGridView _playersDataGridView;
        private readonly DataGridView _myDeathsDataGridView;
        private readonly DataGridView _myKillsDataGridView;
        private readonly Button _pinButton;
        private readonly ToolTip _toolTip;
        private readonly TextBox _noteTextBox;
        private readonly Button _saveNoteButton;
        private readonly Dictionary<string, Button> _categoryButtons = new Dictionary<string, Button>();
        
        private readonly Dictionary<MonitorView, Button> _viewButtons = new Dictionary<MonitorView, Button>();
        private readonly Panel _playerViewPanel;
        private readonly Panel _myDeathsViewPanel;
        private readonly Panel _myKillsViewPanel;
        private readonly Panel _statisticsViewPanel;
        
        private string _ingameName;
        private readonly System.Windows.Forms.Timer _refreshTimer;
        private readonly SpyCitizenAddon _owner;
        private readonly List<PlayerInfo> _playersTodayList = new List<PlayerInfo>();

        // KORREKTUR: Felder für die Statistik-Labels und Buttons hinzugefügt
        private readonly Label _statisticsTitleLabel = new Label { Font = new Font("Segoe UI", 12f, FontStyle.Bold), TextAlign = ContentAlignment.MiddleCenter, Dock = DockStyle.Fill };
        private readonly Label _totalKillsTitleLabel = new Label { AutoSize = true };
        private readonly Label _totalDeathsTitleLabel = new Label { AutoSize = true };
        private readonly Label _kdRatioTitleLabel = new Label { AutoSize = true };
        private readonly Label _mostKilledByTitleLabel = new Label { AutoSize = true };
        private readonly Label _mostKilledPlayerTitleLabel = new Label { AutoSize = true };
        private readonly Label _mostSightedPlayerTitleLabel = new Label { AutoSize = true };
        private readonly Label _mostUsedWeaponTitleLabel = new Label { AutoSize = true };
        private readonly Label _totalKillsLabel = new Label { AutoSize = true };
        private readonly Label _totalDeathsLabel = new Label { AutoSize = true };
        private readonly Label _kdRatioLabel = new Label { AutoSize = true };
        private readonly Label _mostKilledByLabel = new Label { AutoSize = true };
        private readonly Label _mostKilledPlayerLabel = new Label { AutoSize = true };
        private readonly Label _mostSightedPlayerLabel = new Label { AutoSize = true };
        private readonly Label _mostUsedWeaponLabel = new Label { AutoSize = true };
        private readonly Button _refreshStatsButton = new Button { AutoSize = true };
        private readonly Button _resetStatsButton;
        private readonly Label _serverInfoTitleLabel = new Label { Font = new Font("Segoe UI", 11f, FontStyle.Bold), AutoSize = true };
        private readonly Label _serverIpTitleLabel = new Label { AutoSize = true };
        private readonly Label _serverShardIdTitleLabel = new Label { AutoSize = true };
        private readonly Label _serverIpLabel = new Label { AutoSize = true };
        private readonly Label _serverShardIdLabel = new Label { AutoSize = true, MaximumSize = new Size(400, 0) };
        private readonly Label _clientSessionIdLabel = new Label { AutoSize = true, MaximumSize = new Size(400, 0) };

        public bool IsPinned { get; private set; } = true;
        private bool _isApplicationMode;

        #region Win32 API for Focus Handling
        private const int GWL_EXSTYLE = -20;
        private const int WS_EX_NOACTIVATE = 0x08000000;
        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern int GetWindowLong(IntPtr hwnd, int index);
        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern int SetWindowLong(IntPtr hwnd, int index, int newstyle);
        #endregion

        public SpyCitizenForm(SpyCitizenAddon owner, string ingameName, IAddonHost host, bool isApplicationMode)
        {
            _owner = owner;
            _ingameName = ingameName;
            _host = host;
            _isApplicationMode = isApplicationMode;

            this.Text = "SpyCitizen Monitor";
            this.ShowInTaskbar = _isApplicationMode;
            this.MinimizeBox = _isApplicationMode;
            this.FormBorderStyle = _isApplicationMode ? FormBorderStyle.Sizable : FormBorderStyle.SizableToolWindow;
            
            this.TopMost = IsPinned;
            this.MinimumSize = new Size(700, 500);
            this.BackColor = GetOpaqueColor(host.Theme_Background, Color.Black);

            LoadGeometrySettings();

            var topContainer = new Panel { Dock = DockStyle.Top, AutoSize = true };
            var topButtonsPanel = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 40, Padding = new Padding(5), BackColor = Color.FromArgb(50, 50, 50) };
            var separator = new Panel { Dock = DockStyle.Top, Height = 2, BackColor = host.Theme_Accent };
            topContainer.Controls.Add(topButtonsPanel);
            topContainer.Controls.Add(separator);

            _viewButtons[MonitorView.Players] = CreateViewButton("spycitizen.view.playersToday", MonitorView.Players);
            _viewButtons[MonitorView.History] = CreateViewButton("spycitizen.view.history", MonitorView.History);
            _viewButtons[MonitorView.MyDeaths] = CreateViewButton("spycitizen.view.myDeaths", MonitorView.MyDeaths);
            _viewButtons[MonitorView.MyKills] = CreateViewButton("spycitizen.view.myKills", MonitorView.MyKills);
            _viewButtons[MonitorView.Statistics] = CreateViewButton("spycitizen.view.statistics", MonitorView.Statistics);
            foreach(var btn in _viewButtons.Values) { topButtonsPanel.Controls.Add(btn); }
            
            var mainContentPanel = new Panel { Dock = DockStyle.Fill };
            
            _playerViewPanel = new Panel { Dock = DockStyle.Fill };
            _myDeathsViewPanel = new Panel { Dock = DockStyle.Fill };
            _myKillsViewPanel = new Panel { Dock = DockStyle.Fill };
            _statisticsViewPanel = new Panel { Dock = DockStyle.Fill };
            mainContentPanel.Controls.Add(_playerViewPanel);
            mainContentPanel.Controls.Add(_myDeathsViewPanel);
            mainContentPanel.Controls.Add(_myKillsViewPanel);
            mainContentPanel.Controls.Add(_statisticsViewPanel);
            
            _playersDataGridView = CreateBaseDataGridView();
            _playersDataGridView.SelectionChanged += OnPlayerSelected;
            _playersDataGridView.CellDoubleClick += OnPlayerDataGridViewDoubleClick;
            _playerViewPanel.Controls.Add(_playersDataGridView);
            _playersDataGridView.Columns.Add("Name", "Name");
            _playersDataGridView.Columns[0].Width = 150;
            _playersDataGridView.Columns.Add("Sightings", "Sightings");
            _playersDataGridView.Columns[1].Width = 80;
            _playersDataGridView.Columns[1].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            _playersDataGridView.Columns.Add("Category", "Category");
            _playersDataGridView.Columns[2].Width = 100;
            _playersDataGridView.Columns.Add("Note", "Note");
            _playersDataGridView.Columns[3].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            _playersDataGridView.Columns.Add("LastSeen", "Last Seen");
            _playersDataGridView.Columns[4].Width = 150;

            _myDeathsDataGridView = CreateBaseDataGridView();
            _myDeathsViewPanel.Controls.Add(_myDeathsDataGridView);
            _myDeathsDataGridView.Columns.Add("Timestamp", "Timestamp");
            _myDeathsDataGridView.Columns[0].Width = 150;
            _myDeathsDataGridView.Columns.Add("Killer", "Killer");
            _myDeathsDataGridView.Columns[1].Width = 150;
            _myDeathsDataGridView.Columns.Add("Weapon", "Weapon");
            _myDeathsDataGridView.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            _myDeathsDataGridView.Columns.Add("DamageType", "Damage Type");
            _myDeathsDataGridView.Columns[3].Width = 100;
            
            _myKillsDataGridView = CreateBaseDataGridView();
            _myKillsViewPanel.Controls.Add(_myKillsDataGridView);
            _myKillsDataGridView.Columns.Add("Timestamp", "Timestamp");
            _myKillsDataGridView.Columns[0].Width = 150;
            _myKillsDataGridView.Columns.Add("Victim", "Victim");
            _myKillsDataGridView.Columns[1].Width = 150;
            _myKillsDataGridView.Columns.Add("Weapon", "Weapon");
            _myKillsDataGridView.Columns[2].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            _myKillsDataGridView.Columns.Add("DamageType", "Damage Type");
            _myKillsDataGridView.Columns[3].Width = 100;
            
            _resetStatsButton = new Button { AutoSize = true };
            SetupStatisticsPanel();
            
            var actionTableLayout = new TableLayoutPanel { Dock = DockStyle.Bottom, Height = 40, Padding = new Padding(5), ColumnCount = 4, RowCount = 1, BackColor = GetOpaqueColor(((SolidBrush)host.Theme_ButtonNormalBrush).Color, Color.FromArgb(45, 45, 48)) };
            actionTableLayout.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            actionTableLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            actionTableLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 100F));
            actionTableLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 90F));
            var categoryPanel = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.LeftToRight, AutoSize = true, Margin = new Padding(0), WrapContents = false };
            actionTableLayout.Controls.Add(categoryPanel, 0, 0);

            _categoryButtons["Friendly"] = CreateActionButton("spycitizen.category.friendly", "Friendly");
            _categoryButtons["Orga"] = CreateActionButton("spycitizen.category.orga", "Orga");
            _categoryButtons["Hostile"] = CreateActionButton("spycitizen.category.hostile", "Hostile");
            _categoryButtons["Unknown"] = CreateActionButton("spycitizen.category.unknown", "Unknown");
            _categoryButtons["Ignored"] = CreateActionButton("spycitizen.category.ignored", "Ignored");
            foreach (var btn in _categoryButtons.Values) { categoryPanel.Controls.Add(btn); }
            _noteTextBox = new TextBox { Dock = DockStyle.Fill, BackColor = Color.FromArgb(30, 30, 30), ForeColor = host.Theme_Text, BorderStyle = BorderStyle.FixedSingle, Margin = new Padding(8, 3, 3, 3) };
            _noteTextBox.Enter += OnNoteTextBoxEnter;
            _noteTextBox.Leave += OnNoteTextBoxLeave;
            actionTableLayout.Controls.Add(_noteTextBox, 1, 0);
            _saveNoteButton = new Button { Text = "Save Note", Dock = DockStyle.Fill, FlatStyle = FlatStyle.Flat, Margin = new Padding(3), ForeColor = host.Theme_Text };
            _saveNoteButton.FlatAppearance.BorderSize = 0;
            _saveNoteButton.BackColor = GetOpaqueColor(((SolidBrush)host.Theme_ButtonNormalBrush).Color, Color.FromArgb(60, 60, 60));
            _saveNoteButton.Click += SaveNoteButton_Click;
            actionTableLayout.Controls.Add(_saveNoteButton, 2, 0);
            var panicButton = new Button { Text = "PANIC!", Dock = DockStyle.Fill, FlatStyle = FlatStyle.Flat, BackColor = Color.DarkRed, ForeColor = Color.White, Font = new Font("Segoe UI", 9f, FontStyle.Bold), Margin = new Padding(3) };
            panicButton.Name = "panicButton";
            panicButton.FlatAppearance.BorderSize = 0;
            actionTableLayout.Controls.Add(panicButton, 3, 0);

            this.Controls.Add(mainContentPanel);
            this.Controls.Add(actionTableLayout);
            this.Controls.Add(topContainer);

            _pinButton = new Button { Font = new Font("Arial", 8, FontStyle.Bold), Size = new Size(40, 22), Anchor = (AnchorStyles.Top | AnchorStyles.Right), Location = new Point(this.ClientSize.Width - 44, 4), FlatStyle = FlatStyle.Flat, BackColor = Color.FromArgb(40, 40, 40) };
            _pinButton.FlatAppearance.BorderSize = 0;
            _pinButton.Click += PinButton_Click;
            this.Controls.Add(_pinButton);
            _pinButton.BringToFront();
            _pinButton.Visible = !_isApplicationMode;

            _toolTip = new ToolTip();
            UpdatePinButton();
            
            SwitchView(MonitorView.Players);

            _refreshTimer = new System.Windows.Forms.Timer { Interval = 5000 };
            _refreshTimer.Tick += RefreshTimer_Tick;
            _refreshTimer.Start();
        }
        
        public void UpdateUITranslations()
        {
            if (this.InvokeRequired)
            {
                this.BeginInvoke((Action)UpdateUITranslations);
                return;
            }
            
            _host.LogInfo("[SpyCitizen] UpdateUITranslations() called. Setting all texts...");

            _viewButtons[MonitorView.Players].Text = _host.T("spycitizen.view.playersToday");
            _viewButtons[MonitorView.History].Text = _host.T("spycitizen.view.history");
            _viewButtons[MonitorView.MyDeaths].Text = _host.T("spycitizen.view.myDeaths");
            _viewButtons[MonitorView.MyKills].Text = _host.T("spycitizen.view.myKills");
            _viewButtons[MonitorView.Statistics].Text = _host.T("spycitizen.view.statistics");
            
            _categoryButtons["Friendly"].Text = _host.T("spycitizen.category.friendly");
            _categoryButtons["Orga"].Text = _host.T("spycitizen.category.orga");
            _categoryButtons["Hostile"].Text = _host.T("spycitizen.category.hostile");
            _categoryButtons["Unknown"].Text = _host.T("spycitizen.category.unknown");
            _categoryButtons["Ignored"].Text = _host.T("spycitizen.category.ignored");

            _saveNoteButton.Text = _host.T("spycitizen.saveNote");
            var panicButton = this.Controls.Find("panicButton", true).FirstOrDefault();
            if (panicButton != null) panicButton.Text = _host.T("spycitizen.panic");
            
            _myDeathsDataGridView.Columns["Timestamp"].HeaderText = _host.T("spycitizen.deaths.timestamp");
            _myDeathsDataGridView.Columns["Killer"].HeaderText = _host.T("spycitizen.deaths.killer");
            _myDeathsDataGridView.Columns["Weapon"].HeaderText = _host.T("spycitizen.deaths.weapon");
            _myDeathsDataGridView.Columns["DamageType"].HeaderText = _host.T("spycitizen.deaths.damageType");
            
            _myKillsDataGridView.Columns["Timestamp"].HeaderText = _host.T("spycitizen.kills.timestamp");
            _myKillsDataGridView.Columns["Victim"].HeaderText = _host.T("spycitizen.kills.victim");
            _myKillsDataGridView.Columns["Weapon"].HeaderText = _host.T("spycitizen.kills.weapon");
            _myKillsDataGridView.Columns["DamageType"].HeaderText = _host.T("spycitizen.kills.damageType");

            // KORREKTUR: Texte für die Statistik-Labels und Buttons setzen
            _totalKillsTitleLabel.Text = _host.T("spycitizen.stats.totalKills");
            _totalDeathsTitleLabel.Text = _host.T("spycitizen.stats.totalDeaths");
            _kdRatioTitleLabel.Text = _host.T("spycitizen.stats.kdRatio");
            _mostKilledByTitleLabel.Text = _host.T("spycitizen.stats.mostKilledBy");
            _mostKilledPlayerTitleLabel.Text = _host.T("spycitizen.stats.mostKilledPlayer");
            _mostSightedPlayerTitleLabel.Text = _host.T("spycitizen.stats.mostSightedPlayer");
            _mostUsedWeaponTitleLabel.Text = _host.T("spycitizen.stats.mostUsedWeapon");
            _refreshStatsButton.Text = _host.T("spycitizen.stats.refresh");
            _resetStatsButton.Text = _host.T("spycitizen.stats.reset");
            _serverInfoTitleLabel.Text = _host.T("spycitizen.session.title");
            _serverIpTitleLabel.Text = _host.T("spycitizen.session.serverIp");
            _serverShardIdTitleLabel.Text = _host.T("spycitizen.session.shardId");
            
            UpdatePinButton();
            RefreshStatistics();
        }

        private void LoadGeometrySettings()
        {
            this.StartPosition = FormStartPosition.Manual;
            IsPinned = bool.Parse(_host.GetSetting("SpyCitizen_MonitorPinned", "true"));
            this.TopMost = IsPinned;
            int x = int.Parse(_host.GetSetting("SpyCitizen_MonitorX", "100"));
            int y = int.Parse(_host.GetSetting("SpyCitizen_MonitorY", "100"));
            int width = int.Parse(_host.GetSetting("SpyCitizen_MonitorWidth", "800"));
            int height = int.Parse(_host.GetSetting("SpyCitizen_MonitorHeight", "600"));
            this.Location = new Point(x, y);
            this.Size = new Size(width, height);
        }

        private void SaveGeometrySettings()
        {
            _host.SetSetting("SpyCitizen_MonitorPinned", IsPinned.ToString());
            if (this.WindowState == FormWindowState.Normal)
            {
                _host.SetSetting("SpyCitizen_MonitorX", this.Location.X.ToString());
                _host.SetSetting("SpyCitizen_MonitorY", this.Location.Y.ToString());
                _host.SetSetting("SpyCitizen_MonitorWidth", this.Size.Width.ToString());
                _host.SetSetting("SpyCitizen_MonitorHeight", this.Size.Height.ToString());
            }
        }
        
        public void SetApplicationMode(bool enabled)
        {
            if (this.InvokeRequired)
            {
                this.BeginInvoke((Action)(() => SetApplicationMode(enabled)));
                return;
            }
            _isApplicationMode = enabled;
            this.ShowInTaskbar = _isApplicationMode;
            this.MinimizeBox = _isApplicationMode;
            this.FormBorderStyle = _isApplicationMode ? FormBorderStyle.Sizable : FormBorderStyle.SizableToolWindow;
            _pinButton.Visible = !enabled;
        }

        private void OnPlayerDataGridViewDoubleClick(object? sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;
            if (_playersDataGridView.Rows[e.RowIndex].Tag is PlayerInfo playerInfo)
            {
                var details = _db.GetPlayerDetails(playerInfo.Name);
                if (details != null)
                {
                    using (var detailForm = new PlayerDetailForm(details, _owner.IsOrgaScraperEnabled, _host))
                    {
                        detailForm.ShowDialog(this);
                    }
                }
            }
        }
        
        private DataGridView CreateBaseDataGridView()
        {
            var dgv = new DataGridView { Dock = DockStyle.Fill, BackgroundColor = Color.FromArgb(30, 30, 30), ForeColor = _host.Theme_Text, BorderStyle = BorderStyle.None, GridColor = GetOpaqueColor(_host.Theme_Background, Color.Black), AllowUserToAddRows = false, AllowUserToDeleteRows = false, AllowUserToResizeRows = false, RowHeadersVisible = false, SelectionMode = DataGridViewSelectionMode.FullRowSelect, MultiSelect = false, ReadOnly = true };
            dgv.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(50, 50, 50);
            dgv.ColumnHeadersDefaultCellStyle.ForeColor = _host.Theme_Text;
            dgv.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgv.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Single;
            dgv.EnableHeadersVisualStyles = false;
            dgv.DefaultCellStyle.BackColor = Color.FromArgb(30, 30, 30);
            dgv.DefaultCellStyle.ForeColor = _host.Theme_Text;
            dgv.DefaultCellStyle.SelectionBackColor = _host.Theme_Accent;
            dgv.DefaultCellStyle.SelectionForeColor = Color.White;
            return dgv;
        }

        private void RefreshTimer_Tick(object? sender, EventArgs e)
        {
            if ((_currentView == MonitorView.Players || _currentView == MonitorView.History) && this.Visible)
            {
                foreach (DataGridViewRow row in _playersDataGridView.Rows)
                {
                    if (row.Tag is PlayerInfo player) row.Cells[4].Value = FormatLastSeen(player.LastSeenOverall);
                }
            }
        }

        public void SetIngameName(string newName) { _ingameName = newName; RefreshStatistics(); }
        public void TriggerStatisticsRefresh() { if (this.InvokeRequired) this.BeginInvoke((Action)TriggerStatisticsRefresh); else if (_currentView == MonitorView.Statistics) RefreshStatistics(); }
        
        private string FormatLastSeen(DateTime lastSeen)
        {
            var timeSince = DateTime.UtcNow - lastSeen;
            if (timeSince.TotalMinutes < 1) return _host.T("spycitizen.time.justNow");
            if (timeSince.TotalMinutes < 60) return string.Format(_host.T("spycitizen.time.minutesAgo"), Math.Floor(timeSince.TotalMinutes));
            return lastSeen.ToLocalTime().ToString("g");
        }
        
        private void SetupStatisticsPanel()
        {
            _statisticsViewPanel.Padding = new Padding(20);
            _statisticsViewPanel.ForeColor = _host.Theme_Text;
            var layout = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2, RowCount = 14 };
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 250F));
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            layout.Controls.Add(_statisticsTitleLabel, 0, 0);
            layout.SetColumnSpan(_statisticsTitleLabel, 2);
            var separator1 = new Panel { Height = 2, Dock = DockStyle.Fill, BackColor = Color.Gray, Margin = new Padding(0, 10, 0, 10) };
            layout.Controls.Add(separator1, 0, 1);
            layout.SetColumnSpan(separator1, 2);

            // KORREKTUR: Verwende die Klassenfelder anstelle von 'new Label()'
            layout.Controls.Add(_totalKillsTitleLabel, 0, 2);
            layout.Controls.Add(_totalKillsLabel, 1, 2);
            layout.Controls.Add(_totalDeathsTitleLabel, 0, 3);
            layout.Controls.Add(_totalDeathsLabel, 1, 3);
            layout.Controls.Add(_kdRatioTitleLabel, 0, 4);
            layout.Controls.Add(_kdRatioLabel, 1, 4);
            layout.Controls.Add(_mostKilledByTitleLabel, 0, 5);
            layout.Controls.Add(_mostKilledByLabel, 1, 5);
            layout.Controls.Add(_mostKilledPlayerTitleLabel, 0, 6);
            layout.Controls.Add(_mostKilledPlayerLabel, 1, 6);
            layout.Controls.Add(_mostSightedPlayerTitleLabel, 0, 7);
            layout.Controls.Add(_mostSightedPlayerLabel, 1, 7);
            layout.Controls.Add(_mostUsedWeaponTitleLabel, 0, 8);
            layout.Controls.Add(_mostUsedWeaponLabel, 1, 8);
            
            var buttonPanel = new FlowLayoutPanel { Dock = DockStyle.Fill };
            _refreshStatsButton.Click += (s, e) => RefreshStatistics();
            _resetStatsButton.Click += (s, e) => { _db.ResetStatistics(); RefreshStatistics(); };
            buttonPanel.Controls.Add(_refreshStatsButton);
            buttonPanel.Controls.Add(_resetStatsButton);
            layout.Controls.Add(buttonPanel, 0, 13);
            
            var separator2 = new Panel { Height = 2, Dock = DockStyle.Fill, BackColor = Color.Gray, Margin = new Padding(0, 10, 0, 10) };
            layout.Controls.Add(separator2, 0, 9);
            layout.SetColumnSpan(separator2, 2);
            layout.Controls.Add(_serverInfoTitleLabel, 0, 10);
            layout.SetColumnSpan(_serverInfoTitleLabel, 2);
            layout.Controls.Add(_serverIpTitleLabel, 0, 11);
            layout.Controls.Add(_serverIpLabel, 1, 11);
            layout.Controls.Add(_serverShardIdTitleLabel, 0, 12);
            layout.Controls.Add(_serverShardIdLabel, 1, 12);
            
            _statisticsViewPanel.Controls.Add(layout);
        }

        private void RefreshStatistics()
        {
            _serverIpLabel.Text = _db.GetSetting("last_known_ip", "N/A");
            _serverShardIdLabel.Text = _db.GetSetting("last_known_shard_id", "N/A");
            _clientSessionIdLabel.Text = _db.GetSetting("client_session_id", "N/A");
            
            if (string.IsNullOrEmpty(_ingameName))
            {
                _statisticsTitleLabel.Text = _host.T("spycitizen.stats.noNameSet");
                string notAvailable = _host.T("spycitizen.stats.notAvailable");
                _totalKillsLabel.Text = notAvailable;
                _totalDeathsLabel.Text = notAvailable;
                _kdRatioLabel.Text = notAvailable;
                _mostKilledByLabel.Text = notAvailable;
                _mostKilledPlayerLabel.Text = notAvailable;
                _mostSightedPlayerLabel.Text = notAvailable;
                _mostUsedWeaponLabel.Text = notAvailable;
                _resetStatsButton.Enabled = false;
                return;
            }
            _resetStatsButton.Enabled = true;
            _statisticsTitleLabel.Text = string.Format(_host.T("spycitizen.stats.title"), _ingameName);
            var stats = _db.GetStatistics(_ingameName);
            _totalKillsLabel.Text = stats.TotalKills.ToString();
            _totalDeathsLabel.Text = stats.TotalDeaths.ToString();
            _kdRatioLabel.Text = stats.KdRatio.ToString("F2");
            _mostKilledByLabel.Text = stats.MostKilledBy;
            _mostKilledPlayerLabel.Text = stats.MostKilledPlayer;
            _mostSightedPlayerLabel.Text = stats.MostSightedPlayer;
            _mostUsedWeaponLabel.Text = stats.MostUsedWeapon;
        }

        private Button CreateViewButton(string localizationKey, MonitorView view) { var btn = new Button { Text = localizationKey, Tag = view, AutoSize = true, FlatStyle = FlatStyle.Flat }; btn.FlatAppearance.BorderSize = 0; btn.Click += ViewButton_Click; return btn; }
        private void ViewButton_Click(object? sender, EventArgs e) { if (sender is Button { Tag: MonitorView view }) SwitchView(view); }

        private void SwitchView(MonitorView view)
        {
            _currentView = view;
            _playerViewPanel.Visible = view == MonitorView.Players || view == MonitorView.History;
            _myDeathsViewPanel.Visible = view == MonitorView.MyDeaths;
            _myKillsViewPanel.Visible = view == MonitorView.MyKills;
            _statisticsViewPanel.Visible = view == MonitorView.Statistics;
            LoadDataForView(view);
            foreach (var kvp in _viewButtons)
            {
                kvp.Value.BackColor = kvp.Key == view ? _host.Theme_Accent : Color.FromArgb(50, 50, 50);
                kvp.Value.ForeColor = kvp.Key == view ? Color.White : _host.Theme_Text;
            }
        }
        
        private void LoadDataForView(MonitorView view)
        {
            _playersDataGridView.Rows.Clear();
            if (view == MonitorView.History) foreach (var player in _db.GetAllPlayers(_ingameName)) AddPlayerToGrid(player);
            else if (view == MonitorView.Players) foreach (var player in _playersTodayList) AddPlayerToGrid(player);
            else if (view == MonitorView.MyDeaths) { _myDeathsDataGridView.Rows.Clear(); foreach(var ev in _db.GetDeathEvents()) _myDeathsDataGridView.Rows.Add(ev.Timestamp.ToLocalTime().ToString("g"), ev.PlayerName, ev.Weapon, ev.DamageType); }
            else if (view == MonitorView.MyKills) { _myKillsDataGridView.Rows.Clear(); foreach(var ev in _db.GetKillEvents()) _myKillsDataGridView.Rows.Add(ev.Timestamp.ToLocalTime().ToString("g"), ev.PlayerName, ev.Weapon, ev.DamageType); }
            else if(view == MonitorView.Statistics) RefreshStatistics();
        }

        private void AddPlayerToGrid(PlayerInfo player) { int rowIndex = _playersDataGridView.Rows.Add(player.Name, player.TotalSightings, player.Category, player.Note, FormatLastSeen(player.LastSeenOverall)); var row = _playersDataGridView.Rows[rowIndex]; row.Tag = player; row.DefaultCellStyle.ForeColor = GetColorForCategory(player.Category); }
        
        public void ClearPlayersToday()
        {
            if (InvokeRequired) { BeginInvoke((Action)ClearPlayersToday); return; }
            _playersTodayList.Clear();
            if (_currentView == MonitorView.Players) _playersDataGridView.Rows.Clear();
        }

        public void UpdateSessionInfo(string ip, string shardId, string clientSessionId)
        {
            if (InvokeRequired) { BeginInvoke((Action)(() => UpdateSessionInfo(ip, shardId, clientSessionId))); return; }
            _serverIpLabel.Text = ip;
            _serverShardIdLabel.Text = shardId;
            _clientSessionIdLabel.Text = clientSessionId;
        }

        private Color GetColorForCategory(string category) => category switch { "Friendly" => Color.FromArgb(144, 238, 144), "Orga" => Color.FromArgb(135, 206, 250), "Hostile" => Color.FromArgb(240, 128, 128), _ => _host.Theme_Text };
        private Color GetOpaqueColor(Color color, Color fallback) => Color.FromArgb(255, color.R, color.G, color.B);
        private void OnNoteTextBoxEnter(object? sender, EventArgs e) { int style = GetWindowLong(this.Handle, GWL_EXSTYLE); SetWindowLong(this.Handle, GWL_EXSTYLE, style & ~WS_EX_NOACTIVATE); }
        private void OnNoteTextBoxLeave(object? sender, EventArgs e) { int style = GetWindowLong(this.Handle, GWL_EXSTYLE); SetWindowLong(this.Handle, GWL_EXSTYLE, style | WS_EX_NOACTIVATE); }
        public void LoadInitialData() { ClearPlayersToday(); UpdateActionButtons(null); }
        
        private Button CreateActionButton(string localizationKey, string category) 
        { 
            var btn = new Button { Text = localizationKey, Tag = category, AutoSize = true, FlatStyle = FlatStyle.Flat, Enabled = false, Margin = new Padding(0, 3, 3, 3), Height = 23, Padding = new Padding(4, 0, 4, 0), ForeColor = _host.Theme_Text }; 
            btn.FlatAppearance.BorderSize = 0; 
            btn.BackColor = GetOpaqueColor( ((SolidBrush)_host.Theme_ButtonNormalBrush).Color, Color.FromArgb(60, 60, 60)); 
            btn.Click += CategoryButton_Click; 
            return btn; 
        }

        private void CategoryButton_Click(object? sender, EventArgs e)
        {
            if (sender is not Button btn || _playersDataGridView.SelectedRows.Count == 0 || _playersDataGridView.SelectedRows[0].Tag is not PlayerInfo playerInfo || btn.Tag is not string category) return;
            _db.UpdatePlayerCategory(playerInfo.Name, category);
            if (category == "Ignored") { _playersDataGridView.Rows.Remove(_playersDataGridView.SelectedRows[0]); _playersTodayList.RemoveAll(p => p.Name == playerInfo.Name); }
            else
            {
                var player = _db.GetPlayer(playerInfo.Name);
                if (player != null)
                {
                    var row = _playersDataGridView.SelectedRows[0];
                    row.Cells[2].Value = player.Category;
                    row.Tag = player;
                    row.DefaultCellStyle.ForeColor = GetColorForCategory(player.Category);
                    UpdateActionButtons(player);
                    int idx = _playersTodayList.FindIndex(p => p.Name == player.Name);
                    if (idx != -1) _playersTodayList[idx] = player;
                }
            }
        }

        private void SaveNoteButton_Click(object? sender, EventArgs e)
        {
            if (_playersDataGridView.SelectedRows.Count == 0 || _playersDataGridView.SelectedRows[0].Tag is not PlayerInfo playerInfo) return;
            string note = _noteTextBox.Text;
            _db.UpdatePlayerNote(playerInfo.Name, note);
            var player = _db.GetPlayer(playerInfo.Name);
            if (player != null)
            {
                var row = _playersDataGridView.SelectedRows[0];
                row.Cells[3].Value = player.Note;
                row.Tag = player;
                int idx = _playersTodayList.FindIndex(p => p.Name == player.Name);
                if (idx != -1) _playersTodayList[idx] = player;
            }
        }

        private void OnPlayerSelected(object? sender, EventArgs e)
        {
            if (_playersDataGridView.SelectedRows.Count > 0 && _playersDataGridView.SelectedRows[0].Tag is PlayerInfo player) { _noteTextBox.Text = player.Note; UpdateActionButtons(player); }
            else { _noteTextBox.Text = ""; UpdateActionButtons(null); }
        }

        private void UpdateActionButtons(PlayerInfo? player)
        {
            bool enabled = player != null;
            _noteTextBox.Enabled = enabled;
            _saveNoteButton.Enabled = enabled;
            foreach (var btn in _categoryButtons.Values)
            {
                btn.Enabled = enabled;
                Color backColor = GetOpaqueColor( ((SolidBrush)_host.Theme_ButtonNormalBrush).Color, Color.FromArgb(60, 60, 60));
                if (player != null && (string)btn.Tag! == player.Category) backColor = _host.Theme_Accent;
                btn.BackColor = backColor;
            }
        }

        public void AddOrUpdatePlayer(PlayerInfo player)
        {
            var existingPlayerIndex = _playersTodayList.FindIndex(p => p.Name == player.Name);
            if (existingPlayerIndex != -1) _playersTodayList.RemoveAt(existingPlayerIndex);
            if (player.Category != "Ignored") _playersTodayList.Insert(0, player);
            if (this.InvokeRequired) { this.BeginInvoke(new Action(() => AddOrUpdatePlayer(player))); return; }
            if (_currentView != MonitorView.Players) return;
            DataGridViewRow? existingRow = null;
            foreach (DataGridViewRow row in _playersDataGridView.Rows) if(row.Cells[0].Value is string name && name == player.Name) { existingRow = row; break; }
            if (existingRow != null) _playersDataGridView.Rows.Remove(existingRow);
            if (player.Category == "Ignored") return;
            _playersDataGridView.Rows.Insert(0, player.Name, player.TotalSightings, player.Category, player.Note, FormatLastSeen(player.LastSeenOverall));
            var newRow = _playersDataGridView.Rows[0];
            newRow.Tag = player;
            newRow.DefaultCellStyle.ForeColor = GetColorForCategory(player.Category);
        }

        protected override void OnFormClosing(FormClosingEventArgs e) 
        { 
            SaveGeometrySettings();
            if (e.CloseReason == CloseReason.UserClosing) 
            { 
                e.Cancel = true; 
                this.Hide(); 
                UserClosedWindow?.Invoke();
            }
            base.OnFormClosing(e); 
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing) 
            {
                _refreshTimer.Stop();
                _refreshTimer.Dispose();
            }
            base.Dispose(disposing);
        }

        private void PinButton_Click(object? sender, EventArgs e) { IsPinned = !IsPinned; this.TopMost = IsPinned; UpdatePinButton(); _host.SetSetting("SpyCitizen_MonitorPinned", IsPinned.ToString()); }
        
        private void UpdatePinButton() 
        {
            _pinButton.Text = IsPinned ? "PIN" : "WIN";
            _pinButton.ForeColor = IsPinned ? Color.White : Color.Gray;
            string tooltipText = IsPinned ? _host.T("tooltip.pin") : _host.T("tooltip.win");
            _toolTip.SetToolTip(_pinButton, tooltipText);
        }

        protected override bool ShowWithoutActivation => !_isApplicationMode;
        protected override CreateParams CreateParams { get { CreateParams cp = base.CreateParams; if(!_isApplicationMode) cp.ExStyle |= WS_EX_NOACTIVATE; return cp; } }
    }
}