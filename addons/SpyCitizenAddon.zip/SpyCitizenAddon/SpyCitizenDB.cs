using Microsoft.Data.Sqlite;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;

namespace SCOverlay.Addons.SpyCitizen
{
    public record StatisticsSnapshot(
        int TotalKills,
        int TotalDeaths,
        double KdRatio,
        string MostKilledBy,
        string MostKilledPlayer,
        string MostSightedPlayer,
        string MostUsedWeapon
    );

    public record KillDeathEventInfo(DateTime Timestamp, string PlayerName, string Weapon, string DamageType);

    public record PlayerDetailInfo(
        string Name,
        string Category,
        DateTime FirstSeen,
        DateTime LastSeenOverall,
        int TotalSightings,
        string Note,
        int KillsByUser,
        int KilledByPlayer
    );

    public class SpyCitizenDB
    {
        private readonly string _dbPath;
        private const int SIGHTING_COOLDOWN_MINUTES = 30;

        public SpyCitizenDB()
        {
            string appDataDir = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            string addonDataDir = Path.Combine(appDataDir, "SCOverlay", "AddonData");
            Directory.CreateDirectory(addonDataDir);
            _dbPath = Path.Combine(addonDataDir, "spycitizen_monitor.db");
        }

        public string GetConnectionString() => $"Data Source={_dbPath}";

        public void InitializeDatabase()
        {
            using (var connection = new SqliteConnection(GetConnectionString()))
            {
                connection.Open();
                var command = connection.CreateCommand();

                command.CommandText = @"
                    CREATE TABLE IF NOT EXISTS players(
                        name TEXT PRIMARY KEY, 
                        category TEXT DEFAULT 'Unknown', 
                        first_seen TEXT,
                        last_seen_overall TEXT, 
                        last_counted_sighting TEXT,
                        total_sightings INTEGER DEFAULT 0, 
                        notes TEXT DEFAULT '',
                        kills_by_user INTEGER DEFAULT 0,
                        killed_by_player INTEGER DEFAULT 0
                    );
                ";
                command.ExecuteNonQuery();
                command.CommandText = "CREATE INDEX IF NOT EXISTS idx_players_name ON players(name);";
                command.ExecuteNonQuery();

                command.CommandText = @"
                    CREATE TABLE IF NOT EXISTS death_events(
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        timestamp TEXT NOT NULL,
                        killer TEXT NOT NULL,
                        weapon TEXT,
                        damage_type TEXT
                    );
                ";
                command.ExecuteNonQuery();

                command.CommandText = @"
                    CREATE TABLE IF NOT EXISTS kill_events(
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        timestamp TEXT NOT NULL,
                        victim TEXT NOT NULL,
                        weapon TEXT,
                        damage_type TEXT
                    );
                ";
                command.ExecuteNonQuery();

                command.CommandText = @"
                    CREATE TABLE IF NOT EXISTS settings(
                        key TEXT PRIMARY KEY,
                        value TEXT
                    );
                ";
                command.ExecuteNonQuery();
            }
        }

        public string GetSetting(string key, string defaultValue)
        {
            using (var connection = new SqliteConnection(GetConnectionString()))
            {
                connection.Open();
                var command = connection.CreateCommand();
                command.CommandText = "SELECT value FROM settings WHERE key = @key";
                command.Parameters.AddWithValue("@key", key);
                var result = command.ExecuteScalar();
                return result?.ToString() ?? defaultValue;
            }
        }

        public void SetSetting(string key, string value)
        {
            using (var connection = new SqliteConnection(GetConnectionString()))
            {
                connection.Open();
                var command = connection.CreateCommand();
                command.CommandText = "INSERT OR REPLACE INTO settings (key, value) VALUES (@key, @value)";
                command.Parameters.AddWithValue("@key", key);
                command.Parameters.AddWithValue("@value", value);
                command.ExecuteNonQuery();
            }
        }

        public PlayerInfo? AddOrUpdatePlayerSighting(PlayerSighting sighting)
        {
            using (var connection = new SqliteConnection(GetConnectionString()))
            {
                connection.Open();
                using (var command = connection.CreateCommand())
                {
                    command.CommandText = "SELECT last_counted_sighting FROM players WHERE name = @name";
                    command.Parameters.AddWithValue("@name", sighting.Name);
                    object? result = command.ExecuteScalar();

                    if (result != null)
                    {
                        DateTime lastCountedSighting = result is DBNull ? DateTime.MinValue : DateTime.Parse((string)result, null, DateTimeStyles.AdjustToUniversal);
                        command.CommandText = "UPDATE players SET last_seen_overall = @last_seen_overall";
                        if (sighting.Timestamp - lastCountedSighting > TimeSpan.FromMinutes(SIGHTING_COOLDOWN_MINUTES))
                        {
                            command.CommandText += ", total_sightings = total_sightings + 1, last_counted_sighting = @last_counted_sighting";
                            command.Parameters.AddWithValue("@last_counted_sighting", sighting.Timestamp.ToString("o"));
                        }
                        command.CommandText += " WHERE name = @name";
                        command.Parameters.AddWithValue("@last_seen_overall", sighting.Timestamp.ToString("o"));
                        command.ExecuteNonQuery();
                    }
                    else
                    {
                        command.CommandText =
                            "INSERT INTO players (name, first_seen, last_seen_overall, last_counted_sighting, total_sightings, category, notes, kills_by_user, killed_by_player) " +
                            "VALUES (@name, @first_seen, @last_seen_overall, @last_counted_sighting, 1, 'Unknown', '', 0, 0)";
                        string now = sighting.Timestamp.ToString("o");
                        command.Parameters.AddWithValue("@first_seen", now);
                        command.Parameters.AddWithValue("@last_seen_overall", now);
                        command.Parameters.AddWithValue("@last_counted_sighting", now);
                        command.ExecuteNonQuery();
                    }
                }
            }
            return GetPlayer(sighting.Name);
        }
        
        public List<PlayerInfo> GetAllPlayers(string ingameNameToExclude)
        {
            var players = new List<PlayerInfo>();
            using (var connection = new SqliteConnection(GetConnectionString()))
            {
                connection.Open();
                var command = connection.CreateCommand();
                command.CommandText = @"
                    SELECT name, total_sightings, category, notes, last_seen_overall 
                    FROM players 
                    WHERE category != 'Ignored' AND name != @excludeName
                    ORDER BY last_seen_overall DESC";
                
                command.Parameters.AddWithValue("@excludeName", ingameNameToExclude ?? string.Empty);

                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        string notes = !reader.IsDBNull(3) ? reader.GetString(3) : string.Empty;
                        DateTime lastSeen = !reader.IsDBNull(4) ? DateTime.Parse(reader.GetString(4), null, DateTimeStyles.AdjustToUniversal) : DateTime.MinValue;

                        players.Add(new PlayerInfo(
                            reader.GetString(0),
                            reader.GetInt32(1),
                            reader.GetString(2),
                            notes,
                            lastSeen
                        ));
                    }
                }
            }
            return players;
        }

        public void ProcessKillEvent(SpyCitizenParser.KillEvent kill, string ingameName)
        {
            if (string.IsNullOrEmpty(ingameName) || 
                (!kill.Victim.Equals(ingameName, StringComparison.OrdinalIgnoreCase) && 
                 !kill.Killer.Equals(ingameName, StringComparison.OrdinalIgnoreCase)))
            {
                return;
            }

            using (var connection = new SqliteConnection(GetConnectionString()))
            {
                connection.Open();
                
                AddOrUpdatePlayerSighting(new PlayerSighting(kill.Victim, kill.Timestamp));
                AddOrUpdatePlayerSighting(new PlayerSighting(kill.Killer, kill.Timestamp));

                using (var command = connection.CreateCommand())
                {
                    if (kill.Victim.Equals(ingameName, StringComparison.OrdinalIgnoreCase))
                    {
                        command.CommandText = "UPDATE players SET kills_by_user = kills_by_user + 1 WHERE name = @killer";
                        command.Parameters.AddWithValue("@killer", kill.Killer);
                        command.ExecuteNonQuery();
                        
                        command.Parameters.Clear();
                        command.CommandText = "INSERT INTO death_events (timestamp, killer, weapon, damage_type) VALUES (@ts, @killer, @wpn, @dmg)";
                        command.Parameters.AddWithValue("@ts", kill.Timestamp.ToString("o"));
                        command.Parameters.AddWithValue("@killer", kill.Killer);
                        command.Parameters.AddWithValue("@wpn", kill.Weapon);
                        command.Parameters.AddWithValue("@dmg", kill.DamageType);
                        command.ExecuteNonQuery();
                    }
                    else if (kill.Killer.Equals(ingameName, StringComparison.OrdinalIgnoreCase))
                    {
                        command.CommandText = "UPDATE players SET killed_by_player = killed_by_player + 1 WHERE name = @victim";
                        command.Parameters.AddWithValue("@victim", kill.Victim);
                        command.ExecuteNonQuery();

                        command.Parameters.Clear();
                        command.CommandText = "INSERT INTO kill_events (timestamp, victim, weapon, damage_type) VALUES (@ts, @victim, @wpn, @dmg)";
                        command.Parameters.AddWithValue("@ts", kill.Timestamp.ToString("o"));
                        command.Parameters.AddWithValue("@victim", kill.Victim);
                        command.Parameters.AddWithValue("@wpn", kill.Weapon);
                        command.Parameters.AddWithValue("@dmg", kill.DamageType);
                        command.ExecuteNonQuery();
                    }
                }
            }
        }
        
        private string CleanWeaponName(string rawName)
        {
            var parts = rawName.Split('_');
            if (parts.Length >= 3)
            {
                return string.Join("_", parts.Take(3));
            }
            return rawName;
        }

        public StatisticsSnapshot GetStatistics(string ingameName)
        {
            int totalKills = 0;
            int totalDeaths = 0;
            string mostKilledBy = "-";
            string mostKilledPlayer = "-";
            string mostSightedPlayer = "-";
            string mostUsedWeapon = "-";

            if (string.IsNullOrEmpty(ingameName))
            {
                return new StatisticsSnapshot(0, 0, 0, "-", "-", "-", "-");
            }

            using (var connection = new SqliteConnection(GetConnectionString()))
            {
                connection.Open();
                using (var cmd = connection.CreateCommand())
                {
                    cmd.CommandText = "SELECT COUNT(*) FROM kill_events;";
                    totalKills = Convert.ToInt32(cmd.ExecuteScalar() ?? 0);

                    cmd.CommandText = "SELECT COUNT(*) FROM death_events;";
                    totalDeaths = Convert.ToInt32(cmd.ExecuteScalar() ?? 0);

                    cmd.CommandText = "SELECT name, kills_by_user FROM players ORDER BY kills_by_user DESC LIMIT 1;";
                    using (var reader = cmd.ExecuteReader()) { if (reader.Read() && reader.GetInt32(1) > 0) mostKilledBy = $"{reader.GetString(0)} ({reader.GetInt32(1)}x)"; }
                    
                    cmd.CommandText = "SELECT name, killed_by_player FROM players ORDER BY killed_by_player DESC LIMIT 1;";
                    using (var reader = cmd.ExecuteReader()) { if (reader.Read() && reader.GetInt32(1) > 0) mostKilledPlayer = $"{reader.GetString(0)} ({reader.GetInt32(1)}x)"; }

                    cmd.CommandText = "SELECT name, total_sightings FROM players ORDER BY total_sightings DESC LIMIT 1;";
                    using (var reader = cmd.ExecuteReader()) { if (reader.Read() && reader.GetInt32(1) > 0) mostSightedPlayer = $"{reader.GetString(0)} ({reader.GetInt32(1)}x)"; }
                    
                    cmd.CommandText = "SELECT weapon FROM kill_events;";
                    var weaponNames = new List<string>();
                    using (var reader = cmd.ExecuteReader()) { while (reader.Read()) { weaponNames.Add(reader.GetString(0)); } }

                    if (weaponNames.Any())
                    {
                        var weaponCounts = weaponNames
                            .Select(CleanWeaponName)
                            .GroupBy(name => name)
                            .Select(group => new { Name = group.Key, Count = group.Count() })
                            .OrderByDescending(x => x.Count)
                            .FirstOrDefault();

                        if (weaponCounts != null)
                        {
                            mostUsedWeapon = $"{weaponCounts.Name} ({weaponCounts.Count}x)";
                        }
                    }
                }
            }

            double kdRatio = (totalDeaths > 0) ? Math.Round((double)totalKills / totalDeaths, 2) : totalKills;
            return new StatisticsSnapshot(totalKills, totalDeaths, kdRatio, mostKilledBy, mostKilledPlayer, mostSightedPlayer, mostUsedWeapon);
        }

        public void ResetStatistics()
        {
            using (var connection = new SqliteConnection(GetConnectionString()))
            {
                connection.Open();
                var command = connection.CreateCommand();
                command.CommandText = "UPDATE players SET kills_by_user = 0, killed_by_player = 0";
                command.ExecuteNonQuery();
                command.CommandText = "DELETE FROM death_events";
                command.ExecuteNonQuery();
                command.CommandText = "DELETE FROM kill_events";
                command.ExecuteNonQuery();
            }
        }
        
        public List<KillDeathEventInfo> GetDeathEvents()
        {
            var events = new List<KillDeathEventInfo>();
            using (var connection = new SqliteConnection(GetConnectionString()))
            {
                connection.Open();
                var command = connection.CreateCommand();
                command.CommandText = "SELECT timestamp, killer, weapon, damage_type FROM death_events ORDER BY timestamp DESC";
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        events.Add(new KillDeathEventInfo(
                            DateTime.Parse(reader.GetString(0), null, DateTimeStyles.AdjustToUniversal),
                            reader.GetString(1),
                            reader.GetString(2),
                            reader.GetString(3)
                        ));
                    }
                }
            }
            return events;
        }
        
        public List<KillDeathEventInfo> GetKillEvents()
        {
            var events = new List<KillDeathEventInfo>();
            using (var connection = new SqliteConnection(GetConnectionString()))
            {
                connection.Open();
                var command = connection.CreateCommand();
                command.CommandText = "SELECT timestamp, victim, weapon, damage_type FROM kill_events ORDER BY timestamp DESC";
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        events.Add(new KillDeathEventInfo(
                            DateTime.Parse(reader.GetString(0), null, DateTimeStyles.AdjustToUniversal),
                            reader.GetString(1),
                            reader.GetString(2),
                            reader.GetString(3)
                        ));
                    }
                }
            }
            return events;
        }

        public PlayerInfo? GetPlayer(string name)
        {
            using (var connection = new SqliteConnection(GetConnectionString()))
            {
                connection.Open();
                var command = connection.CreateCommand();
                command.CommandText = "SELECT name, total_sightings, category, notes, last_seen_overall FROM players WHERE name = @name";
                command.Parameters.AddWithValue("@name", name);
                
                using (var reader = command.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        string notes = !reader.IsDBNull(3) ? reader.GetString(3) : string.Empty;
                        DateTime lastSeen = !reader.IsDBNull(4) ? DateTime.Parse(reader.GetString(4), null, DateTimeStyles.AdjustToUniversal) : DateTime.MinValue;
                        
                        return new PlayerInfo(
                            reader.GetString(0),
                            reader.GetInt32(1),
                            reader.GetString(2),
                            notes,
                            lastSeen
                        );
                    }
                }
            }
            return null;
        }
        
        public PlayerDetailInfo? GetPlayerDetails(string name)
        {
            using (var connection = new SqliteConnection(GetConnectionString()))
            {
                connection.Open();
                var command = connection.CreateCommand();
                command.CommandText = @"
                    SELECT name, category, first_seen, last_seen_overall, 
                           total_sightings, notes, kills_by_user, killed_by_player 
                    FROM players 
                    WHERE name = @name";
                command.Parameters.AddWithValue("@name", name);
                
                using (var reader = command.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        return new PlayerDetailInfo(
                            reader.GetString(0),
                            reader.GetString(1),
                            DateTime.Parse(reader.GetString(2), null, DateTimeStyles.AdjustToUniversal),
                            DateTime.Parse(reader.GetString(3), null, DateTimeStyles.AdjustToUniversal),
                            reader.GetInt32(4),
                            reader.IsDBNull(5) ? string.Empty : reader.GetString(5),
                            reader.GetInt32(6),
                            reader.GetInt32(7)
                        );
                    }
                }
            }
            return null;
        }

        public void UpdatePlayerCategory(string name, string category)
        {
            using (var connection = new SqliteConnection(GetConnectionString()))
            {
                connection.Open();
                var command = connection.CreateCommand();
                command.CommandText = "UPDATE players SET category = @category WHERE name = @name";
                command.Parameters.AddWithValue("@category", category);
                command.Parameters.AddWithValue("@name", name);
                command.ExecuteNonQuery();
            }
        }

        public void UpdatePlayerNote(string name, string note)
        {
            using (var connection = new SqliteConnection(GetConnectionString()))
            {
                connection.Open();
                var command = connection.CreateCommand();
                command.CommandText = "UPDATE players SET notes = @notes WHERE name = @name";
                command.Parameters.AddWithValue("@notes", note);
                command.Parameters.AddWithValue("@name", name);
                command.ExecuteNonQuery();
            }
        }
    }
}