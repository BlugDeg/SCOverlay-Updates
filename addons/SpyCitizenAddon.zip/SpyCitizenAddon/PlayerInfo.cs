// /SpyCitizenAddon/PlayerInfo.cs
using System;

namespace SCOverlay.Addons.SpyCitizen
{
    public record PlayerInfo(
        string Name,
        int TotalSightings,
        string Category,
        string Note,
        DateTime LastSeenOverall
    );
}