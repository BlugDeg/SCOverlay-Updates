//SpyCitizenAddon/SpyCitizenService.cs

using System;
using System.IO;
using System.Threading;
using SCOverlay.API;
using static SCOverlay.Addons.SpyCitizen.SpyCitizenParser;

namespace SCOverlay.Addons.SpyCitizen
{
    public class SpyCitizenService
    {
        private readonly IAddonHost _host; 
        public event Action<PlayerSighting>? OnPlayerSighted;
        public event Action<KillEvent>? OnKillEvent;
        public event Action<SessionInfo>? OnSessionChanged;
        public event Action? OnLogFileRotated;
        private Thread? _logReaderThread;
        private CancellationTokenSource _cancellationTokenSource = new CancellationTokenSource();
        private long _lastLogPosition = 0;

        public SpyCitizenService(IAddonHost host)
        {
            _host = host;
        }

        public void StartMonitoring(string logFilePath) 
        { 
            if (_logReaderThread != null && _logReaderThread.IsAlive)
            {
                _host.LogInfo("[SpyCitizenService] StartMonitoring called, but thread is already running. Aborting.");
                return;
            } 
            _host.LogInfo($"[SpyCitizenService] Starting monitoring thread for: {logFilePath}");
            _cancellationTokenSource = new CancellationTokenSource(); 
            _logReaderThread = new Thread(() => LogReaderTask(logFilePath, _cancellationTokenSource.Token)) { IsBackground = true, Name = "SpyCitizenLogReader" }; 
            _logReaderThread.Start(); 
        }
        
        public void StopMonitoring() 
        { 
            _host.LogInfo("[SpyCitizenService] StopMonitoring called. Cancelling token.");
            _cancellationTokenSource.Cancel(); 
        }

        private void LogReaderTask(string logFilePath, CancellationToken cancellationToken)
        {
            _host.LogInfo($"[SpyCitizenService] LogReaderTask has started for: {logFilePath}");
            while (!File.Exists(logFilePath) && !cancellationToken.IsCancellationRequested) 
            {
                 _host.LogInfo($"[SpyCitizenService] Log file not found. Waiting 3 seconds...");
                 Thread.Sleep(3000); 
            }
            if (cancellationToken.IsCancellationRequested) return;

            string? clientSessionId = null;
            string? currentIp = null;
            string? currentShardId = null;

            try
            {
                using (var fs = new FileStream(logFilePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                using (var reader = new StreamReader(fs))
                {
                    _lastLogPosition = Math.Max(0, fs.Length - 5120); // Read last 5kb on startup
                    fs.Seek(_lastLogPosition, SeekOrigin.Begin);
                    reader.DiscardBufferedData();
                    _host.LogInfo($"[SpyCitizenService] Starting to read from position {_lastLogPosition}.");

                    while (!cancellationToken.IsCancellationRequested)
                    {
                        if (fs.Length < _lastLogPosition) 
                        { 
                            _host.LogInfo("[SpyCitizenService] Log file has shrunk. Assuming file rotation. Resetting position to 0.");
                            fs.Seek(0, SeekOrigin.Begin); 
                            reader.DiscardBufferedData(); 
                            _lastLogPosition = 0; 
                            OnLogFileRotated?.Invoke(); 
                        }
                        
                        string? line;
                        bool readSomething = false;
                        while ((line = reader.ReadLine()) != null)
                        {
                            readSomething = true;
                            _lastLogPosition = fs.Position;
                            
                            if (TryParsePlayer(line, out var sighting) && sighting != null)
                            {
                                _host.LogInfo($"[SpyCitizenService] Sighting parsed. Invoking OnPlayerSighted for '{sighting.Name}'.");
                                OnPlayerSighted?.Invoke(sighting);
                            }
                            if (TryParseKillEvent(line, out var kill) && kill != null)
                            {
                                _host.LogInfo($"[SpyCitizenService] Kill event parsed. Invoking OnKillEvent.");
                                OnKillEvent?.Invoke(kill);
                            }

                            if (clientSessionId == null && TryParseClientSessionId(line, out var foundSessionId))
                            {
                                clientSessionId = foundSessionId;
                                _host.LogInfo($"[SpyCitizenService] Client Session ID captured: {clientSessionId}");
                            }
                            if (TryParseServerIp(line, out var foundIp))
                            {
                                currentIp = foundIp;
                                _host.LogInfo($"[SpyCitizenService] Server IP captured: {currentIp}");
                            }
                            if (TryParseShardId(line, out var foundShardId))
                            {
                                currentShardId = foundShardId;
                                _host.LogInfo($"[SpyCitizenService] Shard ID captured: {currentShardId}");
                            }

                            if (currentIp != null && currentShardId != null)
                            {
                                _host.LogInfo($"[SpyCitizenService] Both IP and Shard ID captured. Invoking OnSessionChanged.");
                                OnSessionChanged?.Invoke(new SessionInfo(currentIp, currentShardId, clientSessionId));
                                currentIp = null;
                                currentShardId = null;
                            }
                        }
                        
                        if (!readSomething)
                        {
                            Thread.Sleep(100);
                        }
                    }
                }
            }
            catch (Exception ex) { _host.LogError("[SpyCitizenService] CRITICAL Exception in LogReaderTask.", ex); }
            _host.LogInfo($"[SpyCitizenService] LogReaderTask has ended (token cancelled: {cancellationToken.IsCancellationRequested}).");
        }
    }
}