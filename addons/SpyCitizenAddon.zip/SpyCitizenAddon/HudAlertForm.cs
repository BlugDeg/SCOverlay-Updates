using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Text;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace SCOverlay.Addons.SpyCitizen
{
    public enum HudPosition
    {
        TopLeft,
        TopCenter,
        TopRight,
        MiddleLeft,
        MiddleCenter,
        MiddleRight,
        BottomLeft,
        BottomCenter,
        BottomRight
    }

    public class HudAlertForm : Form
    {
        #region Win32 API
        private const int WS_EX_LAYERED = 0x80000;
        private const int WS_EX_TRANSPARENT = 0x20;
        private const int ULW_ALPHA = 0x2;

        [DllImport("user32.dll", ExactSpelling = true, SetLastError = true)]
        private static extern int UpdateLayeredWindow(IntPtr hwnd, IntPtr hdcDst, ref PointApi pptDst, ref SizeApi psize, IntPtr hdcSrc, ref PointApi pptSrc, int crKey, ref BLENDFUNCTION pblend, int dwFlags);
        [DllImport("user32.dll", SetLastError = true)]
        private static extern IntPtr GetDC(IntPtr hWnd);
        [DllImport("gdi32.dll", ExactSpelling = true, SetLastError = true)]
        private static extern IntPtr CreateCompatibleDC(IntPtr hdc);
        [DllImport("gdi32.dll", ExactSpelling = true, SetLastError = true)]
        private static extern bool DeleteDC(IntPtr hdc);
        [DllImport("gdi32.dll", ExactSpelling = true)]
        private static extern IntPtr SelectObject(IntPtr hdc, IntPtr h);
        [DllImport("user32.dll", ExactSpelling = true)]
        private static extern int ReleaseDC(IntPtr hWnd, IntPtr hDC);
        [DllImport("gdi32.dll")]
        public static extern bool DeleteObject(IntPtr hObject);

        [StructLayout(LayoutKind.Sequential)]
        protected struct SizeApi { public int cx; public int cy; public SizeApi(int x, int y) { cx = x; cy = y; } }
        [StructLayout(LayoutKind.Sequential)]
        protected struct PointApi { public int x; public int y; public PointApi(int x, int y) { this.x = x; this.y = y; } }
        [StructLayout(LayoutKind.Sequential)]
        protected struct BLENDFUNCTION { public byte BlendOp; public byte BlendFlags; public byte SourceConstantAlpha; public byte AlphaFormat; }
        #endregion

        private record HudAlert(string Text, DateTime Expiry, Color TextColor, bool Strikethrough);
        private readonly List<HudAlert> _activeAlerts = new List<HudAlert>();
        private readonly System.Windows.Forms.Timer _renderTimer;
        private readonly Font _alertFont = new Font("Arial", 13, FontStyle.Bold);

        public HudAlertForm()
        {
            this.FormBorderStyle = FormBorderStyle.None;
            this.ShowInTaskbar = false;
            this.TopMost = true;
            this.Size = new Size(800, 300);

            _renderTimer = new System.Windows.Forms.Timer { Interval = 100 };
            _renderTimer.Tick += RenderTimer_Tick;
        }

        public void RepositionHud(int monitorIndex, HudPosition position)
        {
            if (this.InvokeRequired)
            {
                this.BeginInvoke((Action)(() => RepositionHud(monitorIndex, position)));
                return;
            }

            var screens = Screen.AllScreens;
            if (screens.Length == 0) return;

            var targetScreen = (monitorIndex >= 0 && monitorIndex < screens.Length) ? screens[monitorIndex] : Screen.PrimaryScreen;

            if (targetScreen == null) return;

            var screenBounds = targetScreen.WorkingArea;
            int x = 0, y = 0;

            switch (position)
            {
                case HudPosition.TopLeft:
                    x = screenBounds.Left + 20;
                    y = screenBounds.Top + 20;
                    break;
                case HudPosition.TopCenter:
                    x = screenBounds.Left + (screenBounds.Width - this.Width) / 2;
                    y = screenBounds.Top + 20;
                    break;
                case HudPosition.TopRight:
                    x = screenBounds.Right - this.Width - 20;
                    y = screenBounds.Top + 20;
                    break;
                case HudPosition.MiddleLeft:
                    x = screenBounds.Left + 20;
                    y = screenBounds.Top + (screenBounds.Height - this.Height) / 2;
                    break;
                case HudPosition.MiddleCenter:
                    x = screenBounds.Left + (screenBounds.Width - this.Width) / 2;
                    y = screenBounds.Top + (screenBounds.Height - this.Height) / 2;
                    break;
                case HudPosition.MiddleRight:
                    x = screenBounds.Right - this.Width - 20;
                    y = screenBounds.Top + (screenBounds.Height - this.Height) / 2;
                    break;
                case HudPosition.BottomLeft:
                    x = screenBounds.Left + 20;
                    y = screenBounds.Bottom - this.Height - 20;
                    break;
                case HudPosition.BottomCenter:
                    x = screenBounds.Left + (screenBounds.Width - this.Width) / 2;
                    y = screenBounds.Bottom - this.Height - 20;
                    break;
                case HudPosition.BottomRight:
                    x = screenBounds.Right - this.Width - 20;
                    y = screenBounds.Bottom - this.Height - 20;
                    break;
            }
            this.Location = new Point(x, y);
        }

        protected override bool ShowWithoutActivation => true;

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ExStyle |= WS_EX_LAYERED | WS_EX_TRANSPARENT;
                return cp;
            }
        }
        
        protected override void OnPaint(PaintEventArgs e) { }
        protected override void OnPaintBackground(PaintEventArgs e) { }

        public void ShowAlert(string name, string category)
        {
            AddAlert($"{name} [{category}]", GetColorForCategory(category), false);
        }

        public void ShowKillConfirmation(string victimName, string victimCategory)
        {
            AddAlert($"KILL: {victimName} [{victimCategory}]", Color.Red, true);
        }
        
        private void AddAlert(string text, Color color, bool strikethrough)
        {
            if (this.InvokeRequired)
            {
                this.BeginInvoke((Action)(() => AddAlert(text, color, strikethrough)));
                return;
            }
            
            lock (_activeAlerts)
            {
                _activeAlerts.Add(new HudAlert(text, DateTime.UtcNow.AddSeconds(3), color, strikethrough));
            }
            
            if (!this.Visible) this.Show();
            if (!_renderTimer.Enabled) _renderTimer.Start();
        }
        
        private void RenderTimer_Tick(object? sender, EventArgs e)
        {
            bool anyLeft;
            lock (_activeAlerts)
            {
                _activeAlerts.RemoveAll(a => a.Expiry < DateTime.UtcNow);
                anyLeft = _activeAlerts.Any();
            }

            UpdateHud();
            
            if (!anyLeft)
            {
                _renderTimer?.Stop();
                if (this.Visible) BeginInvoke((Action)Hide);
            }
        }

        public void ClearAndHide()
        {
            if (InvokeRequired)
            {
                BeginInvoke((Action)ClearAndHide);
                return;
            }

            lock (_activeAlerts) _activeAlerts.Clear();
            _renderTimer?.Stop();
            UpdateHud();
            Hide();
        }
        
        private void UpdateHud()
        {
            if (IsDisposed || !IsHandleCreated || Width <= 0 || Height <= 0) return;

            using (var bitmap = new Bitmap(Width, Height, PixelFormat.Format32bppArgb))
            {
                using (var g = Graphics.FromImage(bitmap))
                {
                    g.Clear(Color.Transparent);
                    g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAlias;

                    List<HudAlert> alertsToDraw;
                    lock (_activeAlerts) alertsToDraw = new List<HudAlert>(_activeAlerts);

                    int y = 10;
                    foreach (var alert in alertsToDraw)
                    {
                        using (var brush = new SolidBrush(alert.TextColor))
                        using (var sf = new StringFormat { Alignment = StringAlignment.Center })
                        {
                            var font = alert.Strikethrough ? new Font(_alertFont, FontStyle.Bold | FontStyle.Strikeout) : _alertFont;
                            g.DrawString(alert.Text, font, brush, new PointF(Width / 2f, y), sf);
                            if (alert.Strikethrough) font.Dispose();
                            y += _alertFont.Height;
                        }
                    }
                }
                
                IntPtr screenDc = GetDC(IntPtr.Zero), memDc = CreateCompatibleDC(screenDc);
                IntPtr hBitmap = IntPtr.Zero, oldBitmap = IntPtr.Zero;
                try
                {
                    hBitmap = bitmap.GetHbitmap(Color.FromArgb(0));
                    oldBitmap = SelectObject(memDc, hBitmap);
                    var size = new SizeApi(bitmap.Width, bitmap.Height);
                    var pointSource = new PointApi(0, 0);
                    var topPos = new PointApi(this.Left, this.Top);
                    var blend = new BLENDFUNCTION { BlendOp = 0, BlendFlags = 0, SourceConstantAlpha = 255, AlphaFormat = 1 };
                    UpdateLayeredWindow(this.Handle, screenDc, ref topPos, ref size, memDc, ref pointSource, 0, ref blend, ULW_ALPHA);
                }
                finally
                {
                    ReleaseDC(IntPtr.Zero, screenDc);
                    if (hBitmap != IntPtr.Zero) { SelectObject(memDc, oldBitmap); DeleteObject(hBitmap); }
                    DeleteDC(memDc);
                }
            }
        }

        private Color GetColorForCategory(string category) => category switch
        {
            "Friendly" => Color.FromArgb(144, 238, 144),
            "Orga" => Color.FromArgb(135, 206, 250),
            "Hostile" => Color.FromArgb(240, 128, 128),
            _ => Color.White,
        };

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _renderTimer?.Stop();
                _renderTimer?.Dispose();
                _alertFont.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}