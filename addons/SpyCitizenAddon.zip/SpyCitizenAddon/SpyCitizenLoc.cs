using System.Collections.Generic;

namespace SCOverlay.Addons.SpyCitizen
{
    public static class SpyCitizenLoc
    {
        public static readonly Dictionary<string, (string en, string de)> Map = new()
        {
            ["spycitizen.setLogPath"] = ("Set Game.log Path", "Game.log Pfad setzen"),
            ["spycitizen.setLogPath.tooltip"] = ("Register your Star Citizen LIVE Game.log in SpyCitien/Settings/Konto/Set Game-Ini  (default path: \"...\\StarCitizen\\LIVE\\Game.log\")", "Registriere deine Star Citizen LIVE Game.log in SpyCitien/Settings/Konto/Set Game-Ini (Normalpfad: \"...\\StarCitizen\\LIVE\\Game.log\")"),
            ["spycitizen.category.friendly"] = ("Friendly", "Freundlich"),
            ["spycitizen.category.orga"] = ("Orga", "Orga"),
            ["spycitizen.category.hostile"] = ("Hostile", "Feindlich"),
            ["spycitizen.category.unknown"] = ("Unknown", "Unbekannt"),
            ["spycitizen.category.ignored"] = ("Ignored", "Ignorieren"),
            ["spycitizen.saveNote"] = ("Save Note", "Notiz speichern"),
            ["spycitizen.panic"] = ("PANIC!", "PANIK!"),
            ["spycitizen.sounds"] = ("Sounds", "Sounds"),
            ["spycitizen.setUnknownAlert"] = ("Set Unknown Alert", "Alarm für Unbekannte"),
            ["spycitizen.setHostileAlert"] = ("Set Hostile Alert", "Alarm für Feindliche"),
            ["spycitizen.setOrgaAlert"] = ("Set Orga Alert", "Alarm für Orga"),
            ["spycitizen.setFriendlyAlert"] = ("Set Friendly Alert", "Alarm für Freundliche"),
            ["spycitizen.hudAlert"] = ("HUD Alert", "HUD-Alarm"),
            ["spycitizen.view.playersToday"] = ("Players Today", "Spieler heute"),
            ["spycitizen.view.history"] = ("History", "Verlauf"),
            ["spycitizen.view.myDeaths"] = ("My Deaths", "Meine Tode"),
            ["spycitizen.view.myKills"] = ("My Kills", "Meine Kills"),
            ["spycitizen.view.statistics"] = ("Statistics", "Statistiken"),
            ["spycitizen.stats.title"] = ("Statistics for: {0}", "Statistiken für: {0}"),
            ["spycitizen.stats.noNameSet"] = ("Please set your in-game name under Settings > Account.", "Bitte In-Game-Namen unter Einstellungen > Konto festlegen."),
            ["spycitizen.stats.notAvailable"] = ("N/A", "N/A"),
            ["spycitizen.stats.totalKills"] = ("Total Kills:", "Gesamte Kills:"),
            ["spycitizen.stats.totalDeaths"] = ("Total Deaths:", "Gesamte Tode:"),
            ["spycitizen.stats.kdRatio"] = ("K/D Ratio:", "K/D-Verhältnis:"),
            ["spycitizen.stats.mostKilledBy"] = ("Most killed by:", "Am häufigsten getötet von:"),
            ["spycitizen.stats.mostKilledPlayer"] = ("Most killed player:", "Am häufigsten getöteter Spieler:"),
            ["spycitizen.stats.mostSightedPlayer"] = ("Most sighted player:", "Am häufigsten gesichteter Spieler:"),
            ["spycitizen.stats.mostUsedWeapon"] = ("Most used weapon:", "Meistgenutzte Waffe:"),
            ["spycitizen.stats.refresh"] = ("Refresh Statistics", "Statistiken aktualisieren"),
            ["spycitizen.stats.reset"] = ("Reset Statistics", "Statistiken zurücksetzen"),
            ["spycitizen.account"] = ("Account", "Konto"),
            ["spycitizen.setIngameName"] = ("Set In-game Name", "In-Game-Namen festlegen"),
            ["spycitizen.time.justNow"] = ("just now", "gerade eben"),
            ["spycitizen.time.minutesAgo"] = ("{0} min ago", "vor {0} Min."),
            ["spycitizen.deaths.timestamp"] = ("Timestamp", "Zeitstempel"),
            ["spycitizen.deaths.killer"] = ("Killed by", "Getötet von"),
            ["spycitizen.deaths.weapon"] = ("Weapon/Method", "Waffe/Methode"),
            ["spycitizen.deaths.damageType"] = ("Damage Type", "Schadenstyp"),
            ["spycitizen.kills.timestamp"] = ("Timestamp", "Zeitstempel"),
            ["spycitizen.kills.victim"] = ("Victim", "Opfer"),
            ["spycitizen.orgaScraperInfo.title"] = ("Organization Info Scan", "Organisation-Info-Scan"),
            ["spycitizen.orgaScraperInfo.body"] = ("When enabled, double-clicking a player will scan their official RSI profile page for organization name and logo.\n\nThis requires an internet connection.\nIf disabled, this feature is skipped to save resources.", "Wenn aktiviert, wird bei einem Doppelklick auf einen Spieler dessen offizielle RSI-Profilseite nach dem Namen und Logo der Organisation durchsucht.\n\nDies erfordert eine Internetverbindung.\nWenn deaktiviert, wird diese Funktion übersprungen, um Ressourcen zu sparen."),
            ["spycitizen.kills.weapon"] = ("Weapon/Method", "Waffe/Methode"),
            ["spycitizen.kills.damageType"] = ("Damage Type", "Schadenstyp"),
            ["spycitizen.orgaScraperToggle"] = ("Orga Info Scan: {0}", "Orga-Info-Scan: {0}"),
            ["spycitizen.session.title"] = ("Current Session", "Aktuelle Sitzung"),
            ["spycitizen.session.serverIp"] = ("Server IP:", "Server IP:"),
            ["spycitizen.session.shardId"] = ("Shard ID:", "Shard ID:"),

            // =======================================================
            // ===== NEU: TEXTE FÜR DIE README HINZUGEFÜGT =====
            // =======================================================
            ["spycitizen.menu.readme"] = ("Readme", "Liesmich"),
            ["spycitizen.readme.title"] = ("SpyCitizen Readme", "SpyCitizen Liesmich"),
            ["spycitizen.readme.content"] = (
                @"--- SpyCitizen Guide ---

SpyCitizen is a powerful intelligence tool that monitors the Star Citizen log file ('Game.log') to track players, kills, and deaths in your session.

*** 1. CRITICAL FIRST STEPS ***
For the addon to work correctly, you MUST configure two settings first:
- Go to 'Settings' -> 'Account' -> 'Set Game.log Path' and select your 'Game.log' file. (Usually located in '...\StarCitizen\LIVE\')
- Go to 'Settings' -> 'Account' -> 'Set In-game Name' and enter your character's exact name. This is crucial for K/D tracking.

--- FEATURES ---

2. The Monitor Window
This is your main interface. You can switch between several views:
- [Players Today]: Shows a live list of players detected in your current server session.
- [History]: Shows all players ever detected across all sessions.
- [My Deaths / My Kills]: A logbook of your personal combat encounters.
- [Statistics]: An overview of your performance, including K/D ratio and more.

You can categorize players by selecting them and clicking 'Friendly', 'Hostile', etc. Double-click a player to view detailed info, including their organization (if Orga-Scan is enabled).

3. On-Screen HUD Alerts
- A discreet pop-up will appear on your screen when a new player is detected.
- You will also see a confirmation when you successfully kill another player.
- You can enable/disable this feature and configure its position and monitor under 'Settings' -> 'HUD Settings'.

4. Sound Alerts
- You can set custom '.wav' sound files to play for different player categories (e.g., a warning sound for 'Hostile' players).
- Configure this under 'Settings' -> 'Sounds'.

5. Orga Info Scan
- This feature scans a player's official RSI profile for their organization name and logo.
- It requires an internet connection and can be toggled under 'Settings' -> 'Monitor Settings'.

6. Monitor Window Modes
- [PIN/WIN]: The 'PIN' button keeps the Monitor window on top of all other applications. 'WIN' makes it behave like a normal window.
- [Application Mode]: In 'Settings' -> 'Monitor Settings', you can switch to 'Application Mode', which gives the Monitor its own taskbar icon and makes it behave like a separate program.",

                @"--- SpyCitizen Anleitung ---

SpyCitizen ist ein mächtiges Spionage-Werkzeug, das die Star Citizen Log-Datei ('Game.log') überwacht, um Spieler, Kills und Tode in deiner Sitzung zu verfolgen.

*** 1. KRITISCHE ERSTE SCHRITTE ***
Damit das Addon korrekt funktioniert, MUSST du zuerst zwei Einstellungen vornehmen:
- Gehe zu 'Einstellungen' -> 'Konto' -> 'Game.log Pfad setzen' und wähle deine 'Game.log'-Datei aus. (Normalerweise unter '...\StarCitizen\LIVE\')
- Gehe zu 'Einstellungen' -> 'Konto' -> 'In-Game-Namen festlegen' und gib den exakten Namen deines Charakters ein. Das ist entscheidend für das K/D-Tracking.

--- FUNKTIONEN ---

2. Das Monitor-Fenster
Dies ist deine Haupt-Oberfläche. Du kannst zwischen mehreren Ansichten wechseln:
- [Spieler heute]: Zeigt eine Live-Liste der Spieler, die in deiner aktuellen Server-Sitzung erkannt wurden.
- [Verlauf]: Zeigt alle Spieler an, die jemals in allen Sitzungen erkannt wurden.
- [Meine Tode / Meine Kills]: Ein Logbuch deiner persönlichen Kampf-Begegnungen.
- [Statistiken]: Eine Übersicht deiner Leistung, inklusive K/D-Verhältnis und mehr.

Du kannst Spieler kategorisieren, indem du sie auswählst und auf 'Freundlich', 'Feindlich' usw. klickst. Doppelklicke auf einen Spieler, um Detail-Infos anzuzeigen, inklusive Organisation (wenn Orga-Scan aktiviert ist).

3. Bildschirm-HUD-Alarme
- Ein diskretes Pop-up erscheint auf deinem Bildschirm, wenn ein neuer Spieler erkannt wird.
- Du siehst ebenfalls eine Bestätigung, wenn du einen anderen Spieler erfolgreich getötet hast.
- Du kannst diese Funktion unter 'Einstellungen' -> 'HUD Einstellungen' aktivieren/deaktivieren und Position sowie Monitor konfigurieren.

4. Sound-Alarme
- Du kannst eigene '.wav'-Sounddateien festlegen, die für verschiedene Spieler-Kategorien abgespielt werden (z.B. ein Warnton für 'Feindlich').
- Konfiguriere dies unter 'Einstellungen' -> 'Sounds'.

5. Orga-Info-Scan
- Diese Funktion scannt das offizielle RSI-Profil eines Spielers nach dem Namen und Logo seiner Organisation.
- Sie erfordert eine Internetverbindung und kann unter 'Einstellungen' -> 'Monitor Settings' umgeschaltet werden.

6. Modi des Monitor-Fensters
- [PIN/WIN]: Der 'PIN'-Button hält das Monitor-Fenster über allen anderen Anwendungen. 'WIN' lässt es sich wie ein normales Fenster verhalten.
- [Application Mode]: Unter 'Einstellungen' -> 'Monitor Settings' kannst du in den 'Application Mode' wechseln. Dadurch erhält der Monitor ein eigenes Taskleisten-Symbol und verhält sich wie ein separates Programm."
            )
        };
    }
}