// /SpyCitizenAddon/OrgaInfoDialog.cs

using System.Drawing;
using System.Windows.Forms;
using SCOverlay.API; // Hinzugefügt

namespace SCOverlay.Addons.SpyCitizen
{
    internal class OrgaInfoDialog : Form
    {
        // Konstruktor angepasst, um den Host zu empfangen
        public OrgaInfoDialog(IAddonHost host)
        {
            // Alle Localization.L.T Aufrufe durch host.T ersetzt
            this.Text = host.T("spycitizen.orgaScraperInfo.title");
            this.Size = new Size(400, 220);
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.StartPosition = FormStartPosition.CenterParent;
            this.ShowInTaskbar = false;
            this.TopMost = true;
            this.BackColor = Color.FromArgb(45, 45, 48);
            this.ForeColor = Color.White;

            var infoLabel = new Label
            {
                Text = host.T("spycitizen.orgaScraperInfo.body"),
                Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleCenter,
                Padding = new Padding(15)
            };

            var okButton = new Button
            {
                Text = host.T("generic.close"), // Besser als "ok"
                DialogResult = DialogResult.OK,
                FlatStyle = FlatStyle.Flat,
                Size = new Size(80, 30),
                Location = new Point(this.ClientSize.Width - 95, this.ClientSize.Height - 45),
                Anchor = AnchorStyles.Bottom | AnchorStyles.Right
            };
            okButton.FlatAppearance.BorderSize = 0;
            okButton.BackColor = Color.FromArgb(60, 60, 60);

            this.Controls.Add(infoLabel);
            this.Controls.Add(okButton);
            this.AcceptButton = okButton;
        }
    }
}