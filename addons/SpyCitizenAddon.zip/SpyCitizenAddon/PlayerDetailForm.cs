//SpyCitizenAddon/PlayerDetailForm.cs

using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using SCOverlay.API;
using SixLabors.ImageSharp;
using SixLabors.ImageSharp.Processing;

using Color = System.Drawing.Color;
using Font = System.Drawing.Font;
using Size = System.Drawing.Size;

namespace SCOverlay.Addons.SpyCitizen
{
    public class PlayerDetailForm : Form
    {
        private readonly IAddonHost _host;
        private readonly PlayerDetailInfo _details;
        private readonly Label _orgaNameLabel = new Label { Text = "Loading...", AutoSize = false, Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft };
        private readonly PictureBox _orgaLogoBox = new PictureBox { Size = new Size(64, 64), SizeMode = PictureBoxSizeMode.Zoom, Dock = DockStyle.Right };
        private readonly ToolTip _toolTip = new ToolTip();
        private string? _orgaUrl = null;
        private readonly bool _isOrgaScraperEnabled;
        private MemoryStream? _logoStream; 

        public PlayerDetailForm(PlayerDetailInfo details, bool isOrgaScraperEnabled, IAddonHost host)
        {
            _details = details;
            _isOrgaScraperEnabled = isOrgaScraperEnabled;
            _host = host;

            this.Text = $"Details for {details.Name}";
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.StartPosition = FormStartPosition.CenterParent;
            this.Size = new Size(480, 520);
            
            this.BackColor = Color.FromArgb(host.Theme_Background.R, host.Theme_Background.G, host.Theme_Background.B);

            this.ForeColor = host.Theme_Text;
            this.ShowInTaskbar = false;
            this.TopMost = true;

            var layout = new TableLayoutPanel { Dock = DockStyle.Fill, Padding = new Padding(15), ColumnCount = 2, RowCount = 10 };
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 120F));
            layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));

            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 28F));
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 28F));
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 70F));
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 28F));
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 28F));
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 28F));
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 28F));
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 28F));
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 40F));

            AddLabel(layout, 0, "Player Name:", details.Name);
            AddLabel(layout, 1, "Category:", details.Category);
            
            var orgaPanel = new Panel { Dock = DockStyle.Fill };
            orgaPanel.Controls.Add(_orgaNameLabel);
            orgaPanel.Controls.Add(_orgaLogoBox);
            AddLabel(layout, 2, "Organization:");
            layout.Controls.Add(orgaPanel, 1, 2);

            _orgaLogoBox.Cursor = Cursors.Hand;
            _orgaLogoBox.Click += OnOrgaClick;
            
            var rsiLink = new LinkLabel { Text = "Open RSI Profile", Dock = DockStyle.Fill, LinkColor = Color.Cyan, ActiveLinkColor = Color.HotPink, TextAlign = ContentAlignment.MiddleLeft };
            rsiLink.LinkClicked += (s, e) => {
                string url = $"https://robertsspaceindustries.com/citizens/{Uri.EscapeDataString(details.Name)}";
                Process.Start(new ProcessStartInfo(url) { UseShellExecute = true });
            };
            AddLabel(layout, 3, "RSI Account:");
            layout.Controls.Add(rsiLink, 1, 3);

            AddLabel(layout, 4, "First Seen:", details.FirstSeen.ToLocalTime().ToString("g"));
            AddLabel(layout, 5, "Last Seen:", details.LastSeenOverall.ToLocalTime().ToString("g"));
            AddLabel(layout, 6, "Sightings:", details.TotalSightings.ToString());
            AddLabel(layout, 7, "Kills/Deaths:", $"{details.KilledByPlayer} / {details.KillsByUser}");
            
            AddLabel(layout, 8, "Notes:");
            var notesBox = new TextBox { Text = details.Note, Multiline = true, ReadOnly = true, Dock = DockStyle.Fill, BackColor = Color.FromArgb(30, 30, 30), ForeColor = Color.Gainsboro, ScrollBars = ScrollBars.Vertical, BorderStyle = BorderStyle.FixedSingle };
            layout.Controls.Add(notesBox, 1, 8);

            var closeButton = new Button { Text = host.T("generic.close"), DialogResult = DialogResult.OK, FlatStyle = FlatStyle.Flat, BackColor = Color.FromArgb(60, 60, 60), Anchor = AnchorStyles.Right };
            closeButton.FlatAppearance.BorderSize = 0;
            layout.Controls.Add(closeButton, 1, 9);
            
            this.Controls.Add(layout);
            this.AcceptButton = closeButton;
            this.Load += OnFormLoad;
        }

        private async void OnFormLoad(object? sender, EventArgs e)
        {
            if (!_isOrgaScraperEnabled)
            {
                _orgaNameLabel.Text = "Disabled";
                return;
            }

            var orgaInfo = await OrgaScraperService.GetOrgaInfoAsync(_details.Name, _host);

            if (this.IsDisposed) return;
            
            this.BeginInvoke((Action)(() => {
                _orgaNameLabel.Text = (orgaInfo.Name == "N/A" || string.IsNullOrEmpty(orgaInfo.Name)) ? "N/A" : $"{orgaInfo.Name} ({orgaInfo.Sid})";
                _orgaUrl = orgaInfo.OrgaUrl;

                if (!string.IsNullOrEmpty(_orgaUrl))
                {
                    string fullOrgaUrl = "https://robertsspaceindustries.com" + _orgaUrl;
                    _toolTip.SetToolTip(_orgaLogoBox, $"Click to open Organization page:\n{fullOrgaUrl}");
                }

                if (orgaInfo.Logo is SixLabors.ImageSharp.Image logoImage)
                {
                    using (logoImage)
                    {
                        _logoStream = new MemoryStream();
                        logoImage.SaveAsPng(_logoStream);
                        _logoStream.Position = 0;
                        _orgaLogoBox.Image = System.Drawing.Image.FromStream(_logoStream);
                    }
                }
            }));
        }

        private void OnOrgaClick(object? sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(_orgaUrl))
            {
                string fullOrgaUrl = "https://robertsspaceindustries.com" + _orgaUrl;
                Process.Start(new ProcessStartInfo(fullOrgaUrl) { UseShellExecute = true });
            }
        }

        private void AddLabel(TableLayoutPanel panel, int row, string title, string? value = null)
        {
            var titleLabel = new Label { Text = title, Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft, Font = new Font("Segoe UI", 9f, FontStyle.Bold) };
            if (row == 2) titleLabel.TextAlign = ContentAlignment.TopLeft;
            panel.Controls.Add(titleLabel, 0, row);
            if(value != null) panel.Controls.Add(new Label { Text = value, Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft }, 1, row);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _orgaLogoBox.Image?.Dispose();
                _logoStream?.Dispose();
                _toolTip.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}