using System.Collections.Generic;

namespace SCOverlay.Addons.ExecTimer
{
    public static class ExecTimerLoc
    {
        public static readonly Dictionary<string, (string en, string de)> Map = new()
        {
            // Timer Window
            ["exectimer.opens_in"] = ("Opens in:", "Öffnet in:"),
            ["exectimer.open"] = ("OPEN", "OFFEN"),
            ["exectimer.closes_in"] = ("Closes in:", "Schliesst in:"),
            ["exectimer.cycle_ends_in"] = ("Cycle ends in:", "Zyklus endet in:"),
            ["exectimer.status_closed"] = ("Closed! Do not Insert!", "Geschlossen! Nicht andocken!"),
            ["exectimer.status_open"] = ("Hangar Open!", "Hangar offen!"),
            ["exectimer.status_blackout"] = ("Blackout", "Blackout"),
            ["exectimer.reset_label"] = ("Resets in:", "Reset in:"),
            ["exectimer.cycle_reset_label"] = ("Cycle resets in:", "Zyklus-Reset in:"),

            // Menu Buttons
            ["exectimer.menu.show_timer"] = ("Show Timer", "Timer anzeigen"),
            ["exectimer.menu.hide_timer"] = ("Hide Timer", "Timer ausblenden"),
            ["exectimer.menu.sound_alert"] = ("Sound Alert: {0}", "Sound-Alarm: {0}"),
            ["exectimer.menu.notif_alert"] = ("Notification Alert: {0}", "Benachrichtigungs-Alarm: {0}"),
            ["exectimer.menu.settings"] = ("Settings", "Einstellungen"),
            ["exectimer.menu.sounds"] = ("Sounds", "Töne"),
            ["exectimer.menu.notifications"] = ("Notifications", "Benachrichtigungen"),
            ["exectimer.menu.volume"] = ("Volume: {0}", "Lautstärke: {0}"),
            ["exectimer.menu.set_sound"] = ("Set Alert Sound", "Alarm-Ton festlegen"),
            ["exectimer.menu.reset_sound"] = ("Reset Alert Sound", "Alarm-Ton zurücksetzen"),
            ["exectimer.menu.test_alert"] = ("Test Alert", "Test-Alarm"),
            ["exectimer.menu.position"] = ("Position: {0}", "Position: {0}"),
            ["exectimer.menu.size"] = ("Size: {0}", "Grösse: {0}"),
            ["exectimer.menu.reset_notifs"] = ("Reset Notification Settings", "Benachrichtigungs-Einstellungen zurücksetzen"),
            
            // NEU: Readme-Texte
            ["exectimer.menu.readme"] = ("Readme", "Liesmich"),
            ["exectimer.readme.title"] = ("ExecTimer Readme", "ExecTimer Liesmich"),
            ["exectimer.readme.content"] = (
                @"--- ExecTimer Guide ---

This addon provides a precise, network-synchronized timer for the Executive Hangars at major landing zones.

1. Core Features:
   - [Show/Hide Timer]: Toggles the visibility of the timer window.
   - [Sound Alert]: Enables or disables a sound when the hangar doors open.
   - [Notification Alert]: Enables or disables a large on-screen notification when the hangar doors open.

2. The Timer Window:
   - The window shows the current status and countdown for the Executive Hangar cycle.
   - It can be moved by dragging it with the mouse.
   - [PIN]: The timer remains always on top, even when the overlay is hidden.
   - [WIN]: The timer hides and reappears together with the main overlay panel.

3. Settings Menu:
   - [Sounds]: Customize the audio alerts.
     - Volume: Adjust the alert volume.
     - Set Alert Sound: Choose your own custom .wav file for the alert.
     - Reset Alert Sound: Revert to the default sound.

   - [Notifications]: Customize the visual alerts.
     - Position: Cycle through 9 different positions for the on-screen notification.
     - Size: Cycle through 3 different sizes (Small, Medium, Large).

The timer automatically syncs with an online time source to ensure accuracy across different clients.",
                
                @"--- ExecTimer Anleitung ---

Dieses Addon stellt einen präzisen, netzwerk-synchronisierten Timer für die Executive Hangars in den Haupt-Landezoonen zur Verfügung.

1. Hauptfunktionen:
   - [Timer anzeigen/ausblenden]: Schaltet die Sichtbarkeit des Timer-Fensters um.
   - [Sound-Alarm]: Aktiviert oder deaktiviert einen Ton, wenn die Hangartore öffnen.
   - [Benachrichtigungs-Alarm]: Aktiviert oder deaktiviert eine grosse Bildschirm-Benachrichtigung, wenn die Hangartore öffnen.

2. Das Timer-Fenster:
   - Das Fenster zeigt den aktuellen Status und den Countdown für den Zyklus des Executive Hangars an.
   - Es kann mit der Maus verschoben werden.
   - [PIN]: Der Timer bleibt immer im Vordergrund, auch wenn das Overlay ausgeblendet ist.
   - [WIN]: Der Timer wird zusammen mit dem Haupt-Overlay ein- und ausgeblendet.

3. Einstellungsmenü:
   - [Töne]: Passe die Audio-Alarme an.
     - Lautstärke: Stelle die Lautstärke des Alarms ein.
     - Alarm-Ton festlegen: Wähle deine eigene .wav-Datei für den Alarm.
     - Alarm-Ton zurücksetzen: Wechsle zurück zum Standard-Ton.

   - [Benachrichtigungen]: Passe die visuellen Alarme an.
     - Position: Wechsle durch 9 verschiedene Positionen für die Benachrichtigung.
     - Grösse: Wechsle durch 3 verschiedene Grössen (Klein, Mittel, Gross).

Der Timer synchronisiert sich automatisch mit einer Online-Zeitquelle, um die Genauigkeit für alle Benutzer zu gewährleisten."
            )
        };
    }
}