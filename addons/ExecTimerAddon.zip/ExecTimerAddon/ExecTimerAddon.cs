using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;
using SCOverlay.API;

namespace SCOverlay.Addons.ExecTimer
{
    [Addon]
    public class ExecTimerAddon : IAddon
    {
        private enum MenuPage { Root, Settings, Sounds, Notifications }

        private IAddonHost? _host;
        private ExecTimerForm? _timerForm;
        private NotificationForm? _notificationForm;
        
        private bool _isToggleEnabled = false;
        private bool _isSoundAlertEnabled = true;
        private bool _isNotificationAlertEnabled = true;
        private float _volume = 0.8f;
        private string? _customSoundPath;
        private NotificationPosition _notificationPosition = NotificationPosition.TopCenter;
        private NotificationSize _notificationSize = NotificationSize.Medium;
        private bool _isOverlayVisible = false;
        private bool _isControllingMenu = false;
        private MenuPage _currentPage = MenuPage.Root;
        
        public string Name => "Executive Hangar Timer";
        public string Author => "Gemini & SCOverlay";
        public string Version => "9.3 Professional"; // Version erhöht

        public void Initialize(IAddonHost host)
        {
            _host = host;
            _host.LogInfo("=================================================");
            _host.LogInfo($"[ExecTimer] Initializing Addon v{Version}...");
            LoadSettings();
            _notificationForm = new NotificationForm();
            _timerForm = new ExecTimerForm(host, PlaySound, ShowHangarOpenNotification, 
                () => _isSoundAlertEnabled, () => _isNotificationAlertEnabled);
            _host.LogInfo("[ExecTimer] Initialization complete.");
        }

        public IDictionary<string, (string en, string de)> GetLocalizations()
        {
            return ExecTimerLoc.Map;
        }

        // NEU: Methode zum Öffnen des Readme-Fensters
        private void OpenReadmeWindow()
        {
            if (_host == null) return;
            var readmeForm = new ReadmeForm(_host);
            readmeForm.ShowDialog();
        }

        public IEnumerable<AddonButton> GetMainMenuButtons()
        {
            if (_host == null) yield break;
            if (!_isControllingMenu)
            {
                yield return new AddonButton("ExecTimerRoot", () => "ExecTimer", () => {
                    _host.LogInfo("[ExecTimer] 'ExecTimer' root button clicked.");
                    _isControllingMenu = true;
                    _currentPage = MenuPage.Root;
                    _host.TakeMenuControl(this, GoBack);
                });
            }
            else
            {
                switch (_currentPage)
                {
                    case MenuPage.Root:
                        yield return new AddonButton("ExecTimerToggle", () => _isToggleEnabled ? _host.T("exectimer.menu.hide_timer") : _host.T("exectimer.menu.show_timer"), () => { _isToggleEnabled = !_isToggleEnabled; UpdateTimerFormVisibility(); });
                        yield return new AddonButton("ToggleSound", () => string.Format(_host.T("exectimer.menu.sound_alert"), _isSoundAlertEnabled ? _host.T("generic.on") : _host.T("generic.off")), () => { _isSoundAlertEnabled = !_isSoundAlertEnabled; _host.Window.ShowNotification($"Sound Alert has been turned {(_isSoundAlertEnabled ? "ON" : "OFF")}"); SaveSettings(); });
                        yield return new AddonButton("ToggleNotif", () => string.Format(_host.T("exectimer.menu.notif_alert"), _isNotificationAlertEnabled ? _host.T("generic.on") : _host.T("generic.off")), () => { _isNotificationAlertEnabled = !_isNotificationAlertEnabled; _host.Window.ShowNotification($"Notification Alert has been turned {(_isNotificationAlertEnabled ? "ON" : "OFF")}"); SaveSettings(); });
                        yield return new AddonButton("GoToSettings", () => _host.T("exectimer.menu.settings"), () => { _currentPage = MenuPage.Settings; _host.TakeMenuControl(this, GoBack); });
                        // NEU: Der Readme-Button am Ende des Hauptmenüs
                        yield return new AddonButton("ExecTimerReadme", () => _host.T("exectimer.menu.readme"), OpenReadmeWindow);
                        break;
                    case MenuPage.Settings:
                        yield return new AddonButton("GoToSounds", () => _host.T("exectimer.menu.sounds"), () => { _currentPage = MenuPage.Sounds; _host.TakeMenuControl(this, GoBack); });
                        yield return new AddonButton("GoToNotifs", () => _host.T("exectimer.menu.notifications"), () => { _currentPage = MenuPage.Notifications; _host.TakeMenuControl(this, GoBack); });
                        break;
                    case MenuPage.Sounds:
                        yield return new AddonButton("Volume", () => string.Format(_host.T("exectimer.menu.volume"), $"{_volume:P0}"), ChangeVolume);
                        yield return new AddonButton("SetSound", () => _host.T("exectimer.menu.set_sound"), SetAlertSound);
                        yield return new AddonButton("ResetSound", () => _host.T("exectimer.menu.reset_sound"), ResetAlertSound);
                        yield return new AddonButton("TestSound", () => _host.T("exectimer.menu.test_alert"), TestFullAlert);
                        break;
                    case MenuPage.Notifications:
                        yield return new AddonButton("CyclePosition", () => string.Format(_host.T("exectimer.menu.position"), _notificationPosition), CycleNotificationPosition);
                        yield return new AddonButton("CycleSize", () => string.Format(_host.T("exectimer.menu.size"), _notificationSize), CycleNotificationSize);
                        yield return new AddonButton("TestNotification", () => _host.T("exectimer.menu.test_alert"), TestFullAlert);
                        yield return new AddonButton("ResetNotifications", () => _host.T("exectimer.menu.reset_notifs"), ResetNotificationSettings);
                        break;
                }
            }
        }
        
        private void LoadSettings() { if (_host == null) return; _host.LogInfo("[ExecTimer] Loading settings..."); _isSoundAlertEnabled = bool.Parse(_host.GetSetting("ExecTimer_SoundAlertEnabled", "true")); _isNotificationAlertEnabled = bool.Parse(_host.GetSetting("ExecTimer_NotificationAlertEnabled", "true")); _volume = float.Parse(_host.GetSetting("ExecTimer_Volume", "0.8"), CultureInfo.InvariantCulture); _customSoundPath = _host.GetSetting("ExecTimer_CustomSoundPath", string.Empty); _notificationPosition = Enum.TryParse<NotificationPosition>(_host.GetSetting("ExecTimer_NotificationPosition", "TopCenter"), out var pos) ? pos : NotificationPosition.TopCenter; _notificationSize = Enum.TryParse<NotificationSize>(_host.GetSetting("ExecTimer_NotificationSize", "Medium"), out var size) ? size : NotificationSize.Medium; _host.LogInfo("[ExecTimer] -> Settings loaded successfully."); }
        private void SaveSettings() { if (_host == null) return; _host.LogInfo("[ExecTimer] Saving settings..."); _host.SetSetting("ExecTimer_SoundAlertEnabled", _isSoundAlertEnabled.ToString()); _host.SetSetting("ExecTimer_NotificationAlertEnabled", _isNotificationAlertEnabled.ToString()); _host.SetSetting("ExecTimer_Volume", _volume.ToString(CultureInfo.InvariantCulture)); _host.SetSetting("ExecTimer_CustomSoundPath", _customSoundPath ?? string.Empty); _host.SetSetting("ExecTimer_NotificationPosition", _notificationPosition.ToString()); _host.SetSetting("ExecTimer_NotificationSize", _notificationSize.ToString()); _host.InvalidateOverlay(); }
        private void ChangeVolume() { _host?.LogInfo("[ExecTimer] 'Volume' button clicked."); _volume = (_volume + 0.1f > 1.01f) ? 0.0f : _volume + 0.1f; SaveSettings(); _host?.Window.ShowNotification($"Alert Volume: {_volume:P0}"); }
        private void SetAlertSound() { _host?.LogInfo("[ExecTimer] 'Set Alert Sound' button clicked."); if (_host == null) return; using (var d = new OpenFileDialog { Title = "Select Alert Sound", Filter = "Sound Files|*.wav" }) { if (d.ShowDialog(_host.Window as IWin32Window) == DialogResult.OK) { _customSoundPath = d.FileName; SaveSettings(); _host.LogInfo($"[ExecTimer] -> Custom sound path set to: {d.FileName}"); _host.Window.ShowNotification($"Alert sound set: {Path.GetFileName(d.FileName)}"); } } }
        private void ResetAlertSound() { _host?.LogInfo("[ExecTimer] 'Reset Alert Sound' button clicked."); _customSoundPath = null; SaveSettings(); _host?.Window.ShowNotification("Alert sound has been reset to default."); }
        private void CycleNotificationPosition() { _host?.LogInfo("[ExecTimer] 'Position' button clicked."); var values = Enum.GetValues(typeof(NotificationPosition)).Cast<NotificationPosition>().ToList(); _notificationPosition = values[ (values.IndexOf(_notificationPosition) + 1) % values.Count ]; SaveSettings(); _host?.LogInfo($"[ExecTimer] -> Notification position set to: {_notificationPosition}"); }
        private void CycleNotificationSize() { _host?.LogInfo("[ExecTimer] 'Size' button clicked."); var values = Enum.GetValues(typeof(NotificationSize)).Cast<NotificationSize>().ToList(); _notificationSize = values[ (values.IndexOf(_notificationSize) + 1) % values.Count ]; SaveSettings(); _host?.LogInfo($"[ExecTimer] -> Notification size set to: {_notificationSize}"); }
        private void ResetNotificationSettings() { _host?.LogInfo("[ExecTimer] 'Reset Notification Settings' button clicked."); _notificationPosition = NotificationPosition.TopCenter; _notificationSize = NotificationSize.Medium; SaveSettings(); _host?.Window.ShowNotification("Notification settings have been reset."); }
        private void TestFullAlert() { _host?.LogInfo("[ExecTimer] 'Test Alert' button clicked."); ShowHangarOpenNotification(); PlaySound("HangarOpen.wav"); }
        private void ShowHangarOpenNotification() => ShowNotification("Executive Hangar is now OPEN!");
        private void ShowNotification(string message) { _host?.LogInfo($"[ExecTimer] Displaying notification: '{message}'"); _notificationForm?.ShowNotification(message, _notificationPosition, _notificationSize, 5); }
        public void PlaySound(string defaultFileName) { if (_host == null) return; string? soundPath = _customSoundPath; if (string.IsNullOrEmpty(soundPath)) { string? addonDirectory = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location); if (addonDirectory != null) soundPath = Path.Combine(addonDirectory, "sounds", defaultFileName); } if (File.Exists(soundPath)) { _host.LogInfo($"[ExecTimer] Playing sound file: {soundPath}"); _host.Sound.PlayFile(soundPath, _volume); } else { _host.LogError($"[ExecTimer] WARNING: Sound file not found at path: '{soundPath}'."); _host.Window.ShowNotification("ExecTimer: Sound file not found!"); } }
        public IEnumerable<AddonControl> GetSettingsControls() => new List<AddonControl>();
        private void GoBack() { _host?.LogInfo("[ExecTimer] 'Back' button clicked."); switch (_currentPage) { case MenuPage.Sounds: case MenuPage.Notifications: _currentPage = MenuPage.Settings; _host?.TakeMenuControl(this, GoBack); break; case MenuPage.Settings: _currentPage = MenuPage.Root; _host?.TakeMenuControl(this, GoBack); break; default: _isControllingMenu = false; _host?.ReleaseMenuControl(); break; } }
        public void OnOverlayVisibilityChanged(bool isVisible) { _host?.LogInfo($"[ExecTimer] Overlay visibility changed: {isVisible}"); _isOverlayVisible = isVisible; if (!isVisible) { _isControllingMenu = false; _host?.ReleaseMenuControl(); } UpdateTimerFormVisibility(); }
        private void UpdateTimerFormVisibility() { if (_timerForm == null) return; bool shouldBeVisible = _isToggleEnabled && (_timerForm.IsPinned || _isOverlayVisible); if (shouldBeVisible) { if (!_timerForm.Visible) _timerForm.Show(); _timerForm.SetTemporaryTopMost(true); _timerForm.BringToFront(); } else { if (_timerForm.Visible) _timerForm.Hide(); _timerForm.SetTemporaryTopMost(false); } }
        public void Shutdown() { _host?.LogInfo("[ExecTimer] Shutting down addon."); _timerForm?.Close(); _timerForm?.Dispose(); _notificationForm?.Dispose(); }
        public void Draw(Graphics g, Rectangle bounds) { }
    }
}