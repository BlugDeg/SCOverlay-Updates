using System;
using System.Drawing;
using System.Windows.Forms;

namespace SCOverlay.Addons.ExecTimer
{
    public class NotificationForm : Form
    {
        private readonly Label _label;
        private readonly System.Windows.Forms.Timer _hideTimer;
        private readonly System.Windows.Forms.Timer _colorTimer;
        private int _rainbowIndex = 0;

        public NotificationForm()
        {
            this.FormBorderStyle = FormBorderStyle.None;
            this.ShowInTaskbar = false;
            this.TopMost = true;
            this.StartPosition = FormStartPosition.Manual;
            this.BackColor = Color.Black;
            this.TransparencyKey = this.BackColor;

            _label = new Label { TextAlign = ContentAlignment.MiddleCenter, Dock = DockStyle.Fill };
            this.Controls.Add(_label);

            _hideTimer = new System.Windows.Forms.Timer();
            _hideTimer.Tick += (sender, args) => { _hideTimer!.Stop(); _colorTimer!.Stop(); this.Hide(); };

            _colorTimer = new System.Windows.Forms.Timer { Interval = 50 };
            _colorTimer.Tick += ColorTimer_Tick;
        }

        private void ColorTimer_Tick(object? sender, EventArgs e)
        {
            _rainbowIndex = (_rainbowIndex + 5) % 360;
            _label.ForeColor = ColorFromHSL(_rainbowIndex, 1.0, 0.5);
        }

        public void ShowNotification(string message, NotificationPosition position, NotificationSize size, int durationSeconds)
        {
            if (this.InvokeRequired)
            {
                this.BeginInvoke((Action)(() => ShowNotification(message, position, size, durationSeconds)));
                return;
            }

            _label.Text = message;
            
            int width, height;
            float fontSize;

            switch (size)
            {
                case NotificationSize.Small:  width = 600; height = 80;  fontSize = 20f; break;
                case NotificationSize.Large:  width = 1000; height = 160; fontSize = 32f; break;
                default: /* Medium */         width = 800; height = 120; fontSize = 24f; break;
            }
            this.Size = new Size(width, height);
            _label.Font = new Font("Arial", fontSize, FontStyle.Bold);

            var screen = Screen.PrimaryScreen ?? Screen.AllScreens[0];
            var screenBounds = screen.WorkingArea;
            int x, y;

            switch (position)
            {
                case NotificationPosition.TopLeft:      x = screenBounds.Left + 20; y = screenBounds.Top + 20; break;
                case NotificationPosition.TopCenter:    x = screenBounds.Left + (screenBounds.Width - this.Width) / 2; y = screenBounds.Top + 20; break;
                case NotificationPosition.TopRight:     x = screenBounds.Right - this.Width - 20; y = screenBounds.Top + 20; break;
                case NotificationPosition.MiddleLeft:   x = screenBounds.Left + 20; y = screenBounds.Top + (screenBounds.Height - this.Height) / 2; break;
                case NotificationPosition.MiddleCenter: x = screenBounds.Left + (screenBounds.Width - this.Width) / 2; y = screenBounds.Top + (screenBounds.Height - this.Height) / 2; break;
                case NotificationPosition.MiddleRight:  x = screenBounds.Right - this.Width - 20; y = screenBounds.Top + (screenBounds.Height - this.Height) / 2; break;
                case NotificationPosition.BottomLeft:   x = screenBounds.Left + 20; y = screenBounds.Bottom - this.Height - 20; break;
                case NotificationPosition.BottomCenter: x = screenBounds.Left + (screenBounds.Width - this.Width) / 2; y = screenBounds.Bottom - this.Height - 20; break;
                case NotificationPosition.BottomRight:  x = screenBounds.Right - this.Width - 20; y = screenBounds.Bottom - this.Height - 20; break;
                default: x=0; y=0; break;
            }
            this.Location = new Point(x, y);

            this.Show();
            _rainbowIndex = 0;
            _colorTimer.Start();
            _hideTimer.Interval = durationSeconds * 1000;
            _hideTimer.Start();
        }

        #region Form Internals & Helpers
        protected override bool ShowWithoutActivation => true;
        protected override CreateParams CreateParams { get { CreateParams cp = base.CreateParams; cp.ExStyle |= 0x20; return cp; } }

        protected override void Dispose(bool disposing)
        {
            if (disposing) { _hideTimer?.Dispose(); _colorTimer?.Dispose(); _label?.Dispose(); }
            base.Dispose(disposing);
        }

        private static Color ColorFromHSL(double h, double s, double l)
        {
            double r = 0, g = 0, b = 0;
            if (l != 0)
            {
                if (s == 0) r = g = b = l;
                else
                {
                    double temp2 = ((l < 0.5) ? l * (1.0 + s) : l + s - (l * s));
                    double temp1 = 2.0 * l - temp2;
                    double[] t3 = { h / 360.0 + 1.0 / 3.0, h / 360.0, h / 360.0 - 1.0 / 3.0 };
                    double[] clr = { 0, 0, 0 };
                    for (int i = 0; i < 3; i++)
                    {
                        if (t3[i] < 0) t3[i] += 1.0;
                        if (t3[i] > 1) t3[i] -= 1.0;
                        if (6.0 * t3[i] < 1.0) clr[i] = temp1 + (temp2 - temp1) * t3[i] * 6.0;
                        else if (2.0 * t3[i] < 1.0) clr[i] = temp2;
                        else if (3.0 * t3[i] < 2.0) clr[i] = (temp1 + (temp2 - temp1) * ((2.0 / 3.0) - t3[i]) * 6.0);
                        else clr[i] = temp1;
                    }
                    r = clr[0]; g = clr[1]; b = clr[2];
                }
            }
            return Color.FromArgb((int)(255 * r), (int)(255 * g), (int)(255 * b));
        }
        #endregion
    }
}