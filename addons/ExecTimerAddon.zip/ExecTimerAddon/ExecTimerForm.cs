// /ExecTimerAddon/ExecTimerForm.cs (Vollständig ersetzen)

using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;
using SCOverlay.API;

namespace SCOverlay.Addons.ExecTimer
{
    public class ExecTimerForm : Form
    {
        private readonly System.Windows.Forms.Timer _updateTimer;
        private readonly Button _pinButton;
        private bool _isPinned = true;
        private readonly ToolTip _toolTip;
        private readonly IAddonHost _host;
        private readonly Action<string> _playSoundAction;
        private readonly Action _showNotificationAction;
        private readonly Func<bool> _isSoundAlertEnabled;
        private readonly Func<bool> _isNotificationAlertEnabled;
        private TimerPhase? _lastPhase;

        public bool IsPinned => _isPinned;

        public void SetTemporaryTopMost(bool top) { if (!_isPinned) this.TopMost = top; }
        private TimeSpan _clockOffset = TimeSpan.Zero;

        #region Timer Logic
        private const int RED_PHASE_DURATION = 120 * 60;
        private const int GREEN_PHASE_DURATION = 60 * 60;
        private const int BLACK_PHASE_DURATION = 5 * 60;
        private const int CYCLE_DURATION_SECONDS = RED_PHASE_DURATION + GREEN_PHASE_DURATION + BLACK_PHASE_DURATION;
        private const long EPOCH_OFFSET_SECONDS = 2809;
        private readonly record struct TimerState(TimerPhase Phase, long PhaseTimeRemaining, long TimeUntilReset, int GreenLamps);
        private enum TimerPhase { Red, Green, Black }
        #endregion

        #region GDI+ Resources
        private readonly Font _mainCountdownFont = new Font("Consolas", 36, FontStyle.Bold);
        private readonly Font _statusFont = new Font("Arial", 12, FontStyle.Bold);
        private readonly Font _smallStatusFont = new Font("Arial", 10);
        private readonly SolidBrush _textColor = new SolidBrush(Color.White);
        private readonly SolidBrush _greenBrush = new SolidBrush(Color.FromArgb(144, 255, 162));
        private readonly SolidBrush _redBrush = new SolidBrush(Color.FromArgb(255, 102, 119));
        private readonly SolidBrush _offBrush = new SolidBrush(Color.FromArgb(50, 50, 50));
        #endregion

        public ExecTimerForm(IAddonHost host, Action<string> playSoundAction, Action showNotificationAction, Func<bool> isSoundAlertEnabled, Func<bool> isNotificationAlertEnabled)
        {
            _host = host;
            _host.LogInfo("[ExecTimer] Initializing ExecTimerForm...");
            _playSoundAction = playSoundAction;
            _showNotificationAction = showNotificationAction;
            _isSoundAlertEnabled = isSoundAlertEnabled;
            _isNotificationAlertEnabled = isNotificationAlertEnabled;
            this.Text = "Executive Hangar Timer";
            this.FormBorderStyle = FormBorderStyle.FixedToolWindow;
            this.ShowInTaskbar = false;
            this.StartPosition = FormStartPosition.Manual;
            this.BackColor = Color.FromArgb(25, 28, 36);
            LoadSettings();
            this.SetStyle(ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint, true);
            _pinButton = new Button { Text = "PIN", Font = new Font("Arial", 9, FontStyle.Bold), Size = new Size(40, 28), Location = new Point(5, 5), FlatStyle = FlatStyle.Flat, ForeColor = Color.White };
            _pinButton.FlatAppearance.BorderSize = 0;
            _pinButton.Click += PinButton_Click;
            this.Controls.Add(_pinButton);
            _toolTip = new ToolTip();
            UpdatePinButtonTooltip();
            _updateTimer = new System.Windows.Forms.Timer { Interval = 1000 };
            _updateTimer.Tick += UpdateTimer_Tick;
            _updateTimer.Start();
            _ = SyncWithNetworkTimeAsync();
        }

        private void LoadSettings() { int x = int.Parse(_host.GetSetting("ExecTimer_WindowX", "-1")); int y = int.Parse(_host.GetSetting("ExecTimer_WindowY", "-1")); _isPinned = bool.Parse(_host.GetSetting("ExecTimer_IsPinned", "true")); if (x != -1 && y != -1) { this.Location = new Point(x, y); } else { var screen = Screen.PrimaryScreen ?? Screen.AllScreens[0]; this.Location = new Point(screen.Bounds.Width - 280 - 20, 20); } this.Size = new Size(280, 240); this.TopMost = _isPinned; }
        private void SavePositionAndPinState() { _host.LogInfo($"[ExecTimer] Saving window state. Pinned: {_isPinned}, Location: {this.Location}"); _host.SetSetting("ExecTimer_WindowX", this.Location.X.ToString()); _host.SetSetting("ExecTimer_WindowY", this.Location.Y.ToString()); _host.SetSetting("ExecTimer_IsPinned", _isPinned.ToString()); }
        private void UpdateTimer_Tick(object? sender, EventArgs e) { var currentState = GetCurrentTimerState(); if (_lastPhase.HasValue && currentState.Phase != _lastPhase.Value) { HandlePhaseChange(currentState.Phase); } _lastPhase = currentState.Phase; this.Invalidate(); }
        private void HandlePhaseChange(TimerPhase newPhase) { _host.LogInfo($"[ExecTimer] Timer phase changed to: {newPhase}"); if (newPhase == TimerPhase.Green) { if (_isNotificationAlertEnabled()) _showNotificationAction(); if (_isSoundAlertEnabled()) _playSoundAction("HangarOpen.wav"); } }
        
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;
            var state = GetCurrentTimerState();
            
            (string topText, Brush topBrush, string mainStatus, Brush mainStatusBrush, string resetLabel, Brush resetBrush) = state.Phase switch
            {
                TimerPhase.Red => (_host.T("exectimer.opens_in"), _textColor, _host.T("exectimer.status_closed"), _redBrush, _host.T("exectimer.reset_label"), _redBrush),
                TimerPhase.Green => (_host.T("exectimer.open"), _greenBrush, _host.T("exectimer.status_open"), _greenBrush, _host.T("exectimer.reset_label"), _redBrush),
                _ => (_host.T("exectimer.cycle_ends_in"), _textColor, _host.T("exectimer.status_blackout"), _offBrush, _host.T("exectimer.cycle_reset_label"), _offBrush)
            };

            var topLabelSize = g.MeasureString(topText, _statusFont);
            g.DrawString(topText, _statusFont, topBrush, (this.ClientRectangle.Width - topLabelSize.Width) / 2, 20);
            string mainCountdownStr = TimeSpan.FromSeconds(state.PhaseTimeRemaining).ToString(@"hh\:mm\:ss");
            var mainCountdownSize = g.MeasureString(mainCountdownStr, _mainCountdownFont);
            g.DrawString(mainCountdownStr, _mainCountdownFont, _textColor, (this.ClientRectangle.Width - mainCountdownSize.Width) / 2, 45);
            float lampsStartX = (this.ClientRectangle.Width - (5 * 20 + 4 * 15)) / 2;
            for (int i = 0; i < 5; i++) { Brush brush = _offBrush; if (state.Phase == TimerPhase.Red) brush = i < state.GreenLamps ? _greenBrush : _redBrush; if (state.Phase == TimerPhase.Green) brush = i < state.GreenLamps ? _greenBrush : _offBrush; g.FillEllipse(brush, lampsStartX + i * (20 + 15), 115, 20, 20); }
            var mainStatusSize = g.MeasureString(mainStatus, _statusFont);
            g.DrawString(mainStatus, _statusFont, mainStatusBrush, (this.ClientRectangle.Width - mainStatusSize.Width) / 2, 160);
            string resetStr = $"{resetLabel} {TimeSpan.FromSeconds(state.TimeUntilReset):hh\\:mm\\:ss}";
            var resetSize = g.MeasureString(resetStr, _smallStatusFont);
            g.DrawString(resetStr, _smallStatusFont, resetBrush, (this.ClientRectangle.Width - resetSize.Width) / 2, 185);
        }

        private TimerState GetCurrentTimerState() { var correctedUtcTime = DateTime.UtcNow + _clockOffset; var totalSecondsSinceEpoch = (long)correctedUtcTime.Subtract(DateTime.UnixEpoch).TotalSeconds; var adjustedSeconds = totalSecondsSinceEpoch - EPOCH_OFFSET_SECONDS; var secondsIntoCycle = adjustedSeconds % CYCLE_DURATION_SECONDS; long timeUntilReset = CYCLE_DURATION_SECONDS - secondsIntoCycle; if (secondsIntoCycle < RED_PHASE_DURATION) { return new TimerState(TimerPhase.Red, RED_PHASE_DURATION - secondsIntoCycle, timeUntilReset, (int)(secondsIntoCycle / 1440)); } long secondsIntoGreenPhase = secondsIntoCycle - RED_PHASE_DURATION; if (secondsIntoGreenPhase < GREEN_PHASE_DURATION) { return new TimerState(TimerPhase.Green, GREEN_PHASE_DURATION - secondsIntoGreenPhase, timeUntilReset, 5 - (int)(secondsIntoGreenPhase / 720)); } return new TimerState(TimerPhase.Black, secondsIntoGreenPhase - GREEN_PHASE_DURATION, timeUntilReset, 0); }
        
        #region Standard Form Methods
        protected override bool ShowWithoutActivation => true;
        private const int WS_EX_NOACTIVATE = 0x08000000;
        protected override CreateParams CreateParams { get { CreateParams cp = base.CreateParams; cp.ExStyle |= WS_EX_NOACTIVATE; return cp; } }
        private void PinButton_Click(object? sender, EventArgs e) { _host.LogInfo("[ExecTimer] 'PIN/WIN' button clicked."); _isPinned = !_isPinned; this.TopMost = _isPinned; _pinButton.Text = _isPinned ? "PIN" : "WIN"; _pinButton.ForeColor = _isPinned ? Color.White : Color.Gray; UpdatePinButtonTooltip(); SavePositionAndPinState(); }
        private void UpdatePinButtonTooltip() { string tooltipText = _isPinned ? _host.T("tooltip.pin") : _host.T("tooltip.win"); _toolTip.SetToolTip(_pinButton, tooltipText); }
        protected override void OnFormClosing(FormClosingEventArgs e) { if (e.CloseReason == CloseReason.UserClosing) { e.Cancel = true; this.Hide(); } else { SavePositionAndPinState(); } base.OnFormClosing(e); }
        private async Task SyncWithNetworkTimeAsync() { _host.LogInfo("[ExecTimer] Attempting to sync with network time..."); try { using (var client = new HttpClient()) { var response = await client.GetStringAsync("http://worldtimeapi.org/api/timezone/Etc/UTC"); using (var jsonDoc = JsonDocument.Parse(response)) { if (jsonDoc.RootElement.TryGetProperty("unixtime", out var unixtimeElement)) { long serverUnixTime = unixtimeElement.GetInt64(); DateTime serverUtc = DateTime.UnixEpoch.AddSeconds(serverUnixTime); _clockOffset = serverUtc - DateTime.UtcNow; _host.LogInfo($"[ExecTimer] -> Time sync successful. Clock offset is: {_clockOffset.TotalSeconds}s"); } } } } catch (Exception ex) { _clockOffset = TimeSpan.Zero; _host.LogError("[ExecTimer] WARNING: Failed to sync with network time.", ex); } }
        #endregion
    }
}