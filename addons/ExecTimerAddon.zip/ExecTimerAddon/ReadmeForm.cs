using System;
using System.Drawing;
using System.Windows.Forms;
using SCOverlay.API;

namespace SCOverlay.Addons.ExecTimer
{
    public class ReadmeForm : Form
    {
        public ReadmeForm(IAddonHost host)
        {
            this.Text = host.T("exectimer.readme.title");
            this.FormBorderStyle = FormBorderStyle.SizableToolWindow;
            this.ShowInTaskbar = false;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Size = new Size(650, 500); // Etwas breiter für besseren Textfluss
            this.TopMost = true;

            Color opaqueBackgroundColor = Color.FromArgb(255, host.Theme_Background);
            
            this.BackColor = opaqueBackgroundColor;
            this.ForeColor = host.Theme_Text;

            var richTextBox = new RichTextBox
            {
                Dock = DockStyle.Fill,
                ReadOnly = true,
                BackColor = this.BackColor,
                ForeColor = this.ForeColor,
                BorderStyle = BorderStyle.None,
                Font = new Font("Consolas", 10F, FontStyle.Regular, GraphicsUnit.Point),
                Text = host.T("exectimer.readme.content"),
                Padding = new Padding(10)
            };

            this.Controls.Add(richTextBox);
            this.Shown += ReadmeForm_Shown;
        }
        
        private void ReadmeForm_Shown(object? sender, EventArgs e)
        {
            this.Activate(); 
            this.BringToFront(); 
        }
    }
}