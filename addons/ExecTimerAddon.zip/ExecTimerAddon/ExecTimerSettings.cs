namespace SCOverlay.Addons.ExecTimer
{
    public enum NotificationPosition { TopLeft, TopCenter, TopRight, MiddleLeft, MiddleCenter, MiddleRight, BottomLeft, BottomCenter, BottomRight }
    public enum NotificationSize { Small, Medium, Large }

    public class ExecTimerSettings
    {
        public bool IsDebugLoggingEnabled { get; set; } = false;
        public bool IsSoundAlertEnabled { get; set; } = true;
        public bool IsNotificationAlertEnabled { get; set; } = true;
        public float Volume { get; set; } = 0.8f;
        public string? CustomSoundPath { get; set; }
        public NotificationPosition Position { get; set; } = NotificationPosition.TopCenter;
        public NotificationSize Size { get; set; } = NotificationSize.Medium;
    }
}